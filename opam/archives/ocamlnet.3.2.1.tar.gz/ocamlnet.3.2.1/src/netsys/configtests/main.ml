external check : unit -> int = "check";;

exit (check())
