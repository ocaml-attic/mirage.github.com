Dynlink.loadfile "foo";;
