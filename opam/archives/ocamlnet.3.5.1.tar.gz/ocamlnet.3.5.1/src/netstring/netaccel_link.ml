(* $Id: netaccel_link.ml 798 2004-07-08 22:11:07Z stolpmann $ *)

Netaccel.init();;
