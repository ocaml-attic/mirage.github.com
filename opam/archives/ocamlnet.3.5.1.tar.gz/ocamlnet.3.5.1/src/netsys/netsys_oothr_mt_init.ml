(* $Id$ *)

(** Initializer for mt programs *)

let () =
  Netsys_oothr_mt.init()
