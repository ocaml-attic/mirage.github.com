Printf.printf "Got from C: %.2f\n" (C_idl.f "Hello world!" 42)
