(* Password generator tool that makes human readable passwords with 
   configurable password lengths and a configurable number of special
   characters, numbers, and capital letters 
*)

(* opening the unix library. Will be using this library to help select a 
   random seed for our initialization of Random *)
open Unix;;

(* type phonem will be used for creating the password, it is made up of
   the letter that will be added to the password and a type such as dipthong
*)
type phonem = {letter:string;value:string};;
(* type t is used to store all configurable values passed in by the user *)
type t = {passwdlength:int;numbers:int;specials:int;capitals:int}
(* charquad contains all letters and groups of letters for the password *)
let charquad = [|{letter="a";value="V" };{letter="ae";value="VD" };
		 {letter="ah";value="VD" };{letter="ai";value="VD" };
		 {letter="b";value="C" };{letter="c";value="C" };
		 {letter="ch";value="CD" };{letter="d";value="C" };
		 {letter="e";value="V" };{letter="ee";value="VD" };
		 {letter="ei";value="VD" };{letter="f";value="C" };
		 {letter="g";value="C" };{letter="gh";value="CDN" };
		 {letter="h";value="C" };{letter="i";value="V" };
		 {letter="ie";value="VD" };{letter="j";value="C" };
		 {letter="k";value="C" };{letter="l";value="C" };
		 {letter="m";value="C" };{letter="n";value="C" };
		 {letter="ng";value="CDN" };{letter="o";value="V" };
		 {letter="oh";value="VD" };{letter="oo";value="VD"};
		 {letter="p";value="C" };{letter="ph";value="CD" };
		 {letter="qu";value="CD"};{letter="r";value="C" };
		 {letter="s";value="C" };{letter="sh";value="CD"};
		 {letter="t";value="C" };{letter="th";value="CD"};
		 {letter="u";value="V" };{letter="v";value="C" };
		 {letter="w";value="C" };{letter="x";value="C" };
		 {letter="y";value="C" };{letter="z";value="C" }|]
(*capquad contains all capital letters for the password*)		 
let capquad = [|{letter="A";value="A" };{letter="B";value="A" };
		{letter="C";value="A" };{letter="D";value="A" };
		{letter="E";value="A" };{letter="F";value="A" };
		{letter="G";value="A" };{letter="H";value="A" };
		{letter="I";value="A" };{letter="J";value="A" };
		{letter="K";value="A" };{letter="L";value="A" };
		{letter="M";value="A" };{letter="N";value="A" };
		{letter="O";value="A" };{letter="P";value="A" };
		{letter="Q";value="A" };{letter="R";value="A" };
		{letter="S";value="A" };{letter="T";value="A" };
		{letter="U";value="A" };{letter="V";value="A" };
		{letter="W";value="A" };{letter="X";value="A" };
		{letter="Y";value="A" };{letter="Z";value="A" }|]
(* specquad contains all acceptable special characters for the password,
   this one may get larger if more special characters are allowed at some
   point in the future *)
let specquad = [|{letter="!";value="S"};{letter="$";value="S"};
		 {letter="&";value="S"};{letter="*";value="S"};
		 {letter="<";value="S"};{letter=">";value="S"}|]
(* numquad contains all numbers for the password *)
let numquad = [|{letter="0";value="N"};{letter="1";value="N"};
		{letter="2";value="N"};{letter="3";value="N"};
		{letter="4";value="N"};{letter="5";value="N"};
		{letter="6";value="N"};{letter="7";value="N"};
		{letter="8";value="N"};{letter="9";value="N"}|]
(* prev is used to store the previous acceptable character that was added
   to the password *)  
let prev = ref ""
(* init is used to initialize all configurable values *) 
let init ?(max=8) ?(nums=1) ?(spec=1) ?(caps=0) () =
  let check value def = if value > 0 then value else def in
    {passwdlength=(check max 8);numbers=(check nums 1);
     specials=(check spec 1);capitals=(check caps 0)}
(* the fill array function is used to determine where to place all special
   characters which is anything other than those that come from charquad *)
let rec fill_array parray max nums spec caps =
  let c = Random.int max in
    if(nums != 0) then
      if(parray.(c) = "C") then 
	(parray.(c)<-"N";
	 fill_array parray max (nums-1) spec caps)
      else
	fill_array parray max nums spec caps
    else if(spec != 0) then
      if(parray.(c) = "C") then
	(parray.(c)<-"S"; 
	 fill_array parray max nums (spec-1) caps)
      else
	fill_array parray max nums spec caps
    else if(caps != 0) then
      if(parray.(c) = "C") then
	(parray.(c)<-"A"; 
	 fill_array parray max nums spec (caps-1))
      else
	fill_array parray max nums spec caps
(* the userpassword function is used to select the next acceptable character
   for our password. It reads the position array that we generated in fill
   array to discover what type of character to choose. It also follows follows
   a few basic rules to keep the password human readable *)
let rec userpassword i parray max =
  let num = Random.int 40 in
    match [parray.(i);(string_of_int i)] with
	["C";"0"] -> (if (match [charquad.(num).value;parray.(i+1)] with
			      ["CDN";_] -> true
			    | ["CD"|"VD";"A"|"S"|"N"] -> true
			    | _ -> false) then userpassword i parray max
		      else (prev:=charquad.(num).value;
			   charquad.(num).letter))
      | ["N";_] -> numquad.(Random.int 10).letter
      | ["S";_] -> specquad.(Random.int 6).letter
      | ["A";_] -> capquad.(Random.int 26).letter
      | _ -> (if ((i = max-1) && (match [charquad.(num).value;!prev] with
				      ["CD"|"CDN"|"VD";_] -> true
				    | ["C";"C"|"CD"|"CDN"] -> true
				    | ["V";"V"|"VD"] -> true
				    | _ -> false)) then userpassword i parray max
	      else if ((i<max-1)&&(match [charquad.(num).value;parray.(i+1);!prev] with
		      ["CD"|"CDN"|"C";_;"C"|"CDN"|"CD"] -> true
		    | ["VD"|"V";_;"V"|"VD"] -> true
		    | ["CD"|"CDN"|"VD";"N"|"S"|"A";_] -> true
		    | _ -> false)) then userpassword i parray max
	
	      else (prev:=charquad.(num).value;
 		    charquad.(num).letter))
(* passwdgen is our driver function which calls on our other two functions to 
   create the password. This function is called by the end user and returns the
   finished password to that user. *)
let passwdgen config =
  let parray = Array.make config.passwdlength "C" in
  let pwd = ref "" in
    (fill_array parray config.passwdlength config.numbers config.specials config.capitals;
     for i = 0 to (config.passwdlength-1)
     do
       if(i == String.length !pwd) then
	 pwd := !pwd ^ (userpassword i parray config.passwdlength)
     done);
  !pwd;;
(* need to make sure we select a random seed so that not all passwords
   generated are the same *)
Random.init (int_of_float(Sys.time()) + Unix.getpid());;
