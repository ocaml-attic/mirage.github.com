Mikmatch
========

See `INSTALL` for the installation instructions.
See http://mjambon.com/micmatch.html for the tutorial.
See `pcre/test1.ml` for a complete set of examples.

Please send bug reports, comments or feature requests to 
Martin Jambon <martin@mjambon.com>
