type token =
  | STRING of (string)
  | INT of (int)
  | EOF
  | FLOAT of (float)
  | CHAR of (char)
  | SEMI
  | BEGIN
  | END
  | IDENT of (string)
  | LBRACKET
  | RBRACKET
  | PLUSEQUAL
  | MINUSEQUAL
  | TRUE
  | FALSE
  | INCLUDE
  | OBJECTS
  | LIBRARY
  | PROGRAM
  | CONFIG
  | EQUAL
  | LPAREN
  | RPAREN
  | FILES
  | REQUIRES
  | TYPE
  | FILE
  | USE
  | PACK

open Parsing;;
# 19 "lib/buildOCPParser.mly"

  open BuildOCPTypes

  (* TODO: location of the type in ocamlyacc is erroneous, for example here token "main"
   type is located in the .mli/.ml file instead of the .mly file. *)

# 41 "lib/buildOCPParser.ml"
let yytransl_const = [|
    0 (* EOF *);
  261 (* SEMI *);
  262 (* BEGIN *);
  263 (* END *);
  265 (* LBRACKET *);
  266 (* RBRACKET *);
  267 (* PLUSEQUAL *);
  268 (* MINUSEQUAL *);
  269 (* TRUE *);
  270 (* FALSE *);
  271 (* INCLUDE *);
  272 (* OBJECTS *);
  273 (* LIBRARY *);
  274 (* PROGRAM *);
  275 (* CONFIG *);
  276 (* EQUAL *);
  277 (* LPAREN *);
  278 (* RPAREN *);
  279 (* FILES *);
  280 (* REQUIRES *);
  281 (* TYPE *);
  282 (* FILE *);
  283 (* USE *);
  284 (* PACK *);
    0|]

let yytransl_block = [|
  257 (* STRING *);
  258 (* INT *);
  259 (* FLOAT *);
  260 (* CHAR *);
  264 (* IDENT *);
    0|]

let yylhs = "\255\255\
\001\000\002\000\002\000\002\000\004\000\004\000\004\000\003\000\
\003\000\003\000\003\000\003\000\003\000\006\000\006\000\006\000\
\007\000\007\000\007\000\007\000\007\000\007\000\007\000\008\000\
\008\000\008\000\008\000\008\000\008\000\008\000\008\000\008\000\
\005\000\005\000\005\000\011\000\011\000\010\000\012\000\012\000\
\012\000\012\000\009\000\014\000\014\000\013\000\013\000\013\000\
\013\000\013\000\000\000"

let yylen = "\002\000\
\002\000\000\000\002\000\002\000\001\000\001\000\001\000\005\000\
\005\000\003\000\002\000\001\000\007\000\000\000\002\000\002\000\
\001\000\003\000\003\000\003\000\002\000\003\000\003\000\002\000\
\003\000\003\000\003\000\003\000\003\000\003\000\003\000\003\000\
\000\000\002\000\002\000\000\000\003\000\003\000\000\000\002\000\
\002\000\002\000\003\000\002\000\002\000\000\000\003\000\002\000\
\005\000\005\000\002\000"

let yydefred = "\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\051\000\000\000\000\000\012\000\017\000\004\000\
\000\000\007\000\006\000\005\000\000\000\000\000\000\000\000\000\
\000\000\000\000\011\000\000\000\000\000\000\000\000\000\000\000\
\021\000\000\000\024\000\001\000\003\000\000\000\000\000\010\000\
\000\000\026\000\029\000\027\000\030\000\025\000\031\000\032\000\
\028\000\000\000\020\000\018\000\000\000\000\000\000\000\000\000\
\023\000\022\000\019\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\040\000\042\000\041\000\038\000\000\000\035\000\008\000\034\000\
\016\000\009\000\015\000\000\000\000\000\048\000\000\000\044\000\
\045\000\043\000\000\000\000\000\000\000\047\000\000\000\000\000\
\013\000\037\000\000\000\000\000\049\000\050\000"

let yydgoto = "\002\000\
\011\000\012\000\013\000\023\000\062\000\065\000\014\000\015\000\
\051\000\033\000\085\000\056\000\071\000\072\000"

let yysindex = "\005\000\
\071\255\000\000\071\255\048\255\032\255\018\255\062\255\080\255\
\009\255\039\255\000\000\033\000\071\255\000\000\000\000\000\000\
\025\255\000\000\000\000\000\000\054\255\083\255\086\255\098\255\
\103\255\079\255\000\000\096\255\096\255\105\255\102\255\102\255\
\000\000\113\255\000\000\000\000\000\000\104\255\043\255\000\000\
\034\255\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\031\255\000\000\000\000\105\255\105\255\105\255\108\255\
\000\000\000\000\000\000\099\255\043\255\115\255\043\255\034\255\
\116\255\034\255\106\255\031\255\106\255\006\255\118\255\106\255\
\000\000\000\000\000\000\000\000\034\255\000\000\000\000\000\000\
\000\000\000\000\000\000\043\255\031\255\000\000\031\255\000\000\
\000\000\000\000\096\255\119\255\107\255\000\000\123\255\106\255\
\000\000\000\000\031\255\031\255\000\000\000\000"

let yyrindex = "\000\000\
\125\000\000\000\001\000\124\255\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\001\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\122\255\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\126\255\000\000\
\127\255\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\125\255\000\000\000\000\122\255\122\255\122\255\000\000\
\000\000\000\000\000\000\000\000\005\255\000\000\005\255\127\255\
\000\000\127\255\003\255\074\255\010\255\000\000\000\000\128\255\
\000\000\000\000\000\000\000\000\127\255\000\000\000\000\000\000\
\000\000\000\000\000\000\114\255\074\255\000\000\131\255\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\003\255\
\000\000\000\000\074\255\074\255\000\000\000\000"

let yygindex = "\000\000\
\000\000\065\000\000\000\079\000\218\255\019\000\220\255\219\255\
\227\255\077\000\205\255\066\000\191\255\000\000"

let yytablesize = 264
let yytable = "\052\000\
\002\000\063\000\086\000\036\000\066\000\001\000\088\000\036\000\
\036\000\036\000\036\000\033\000\036\000\089\000\036\000\036\000\
\036\000\087\000\027\000\094\000\091\000\095\000\078\000\063\000\
\080\000\063\000\033\000\066\000\034\000\066\000\036\000\067\000\
\036\000\101\000\102\000\068\000\069\000\036\000\064\000\035\000\
\066\000\005\000\024\000\025\000\100\000\093\000\063\000\061\000\
\017\000\038\000\005\000\026\000\003\000\004\000\039\000\005\000\
\007\000\008\000\070\000\009\000\010\000\096\000\006\000\018\000\
\019\000\020\000\021\000\016\000\022\000\010\000\007\000\008\000\
\028\000\009\000\010\000\003\000\004\000\037\000\005\000\046\000\
\046\000\029\000\081\000\046\000\083\000\006\000\041\000\030\000\
\030\000\040\000\031\000\047\000\048\000\007\000\008\000\092\000\
\009\000\010\000\042\000\032\000\043\000\045\000\049\000\044\000\
\050\000\053\000\030\000\057\000\058\000\054\000\030\000\030\000\
\055\000\059\000\018\000\019\000\020\000\076\000\073\000\074\000\
\075\000\079\000\082\000\060\000\002\000\097\000\084\000\090\000\
\098\000\099\000\002\000\039\000\033\000\014\000\046\000\033\000\
\036\000\046\000\077\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\002\000"

let yycheck = "\029\000\
\000\000\039\000\068\000\001\001\041\000\001\000\001\001\005\001\
\006\001\007\001\001\001\007\001\010\001\008\001\005\001\006\001\
\007\001\069\000\001\001\085\000\072\000\087\000\061\000\061\000\
\063\000\063\000\022\001\064\000\020\001\066\000\028\001\001\001\
\000\000\099\000\100\000\005\001\006\001\028\001\005\001\001\001\
\077\000\008\001\011\001\012\001\096\000\084\000\084\000\005\001\
\001\001\025\001\008\001\020\001\005\001\006\001\001\001\008\001\
\023\001\024\001\028\001\026\001\027\001\091\000\015\001\016\001\
\017\001\018\001\019\001\003\000\004\000\027\001\023\001\024\001\
\011\001\026\001\027\001\005\001\006\001\013\000\008\001\001\001\
\007\001\020\001\064\000\010\001\066\000\015\001\001\001\009\001\
\009\001\007\001\011\001\013\001\014\001\023\001\024\001\077\000\
\026\001\027\001\001\001\020\001\024\000\025\000\026\000\001\001\
\009\001\001\001\009\001\031\000\032\000\005\001\009\001\009\001\
\008\001\001\001\016\001\017\001\018\001\010\001\053\000\054\000\
\055\000\007\001\007\001\020\001\000\000\007\001\021\001\010\001\
\022\001\007\001\007\001\010\001\007\001\007\001\010\001\022\001\
\009\001\007\001\060\000\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\007\001"

let yynames_const = "\
  EOF\000\
  SEMI\000\
  BEGIN\000\
  END\000\
  LBRACKET\000\
  RBRACKET\000\
  PLUSEQUAL\000\
  MINUSEQUAL\000\
  TRUE\000\
  FALSE\000\
  INCLUDE\000\
  OBJECTS\000\
  LIBRARY\000\
  PROGRAM\000\
  CONFIG\000\
  EQUAL\000\
  LPAREN\000\
  RPAREN\000\
  FILES\000\
  REQUIRES\000\
  TYPE\000\
  FILE\000\
  USE\000\
  PACK\000\
  "

let yynames_block = "\
  STRING\000\
  INT\000\
  FLOAT\000\
  CHAR\000\
  IDENT\000\
  "

let yyact = [|
  (fun _ -> failwith "parser")
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'statements) in
    Obj.repr(
# 63 "lib/buildOCPParser.mly"
               ( _1 )
# 261 "lib/buildOCPParser.ml"
               : BuildOCPTypes.statement list))
; (fun __caml_parser_env ->
    Obj.repr(
# 67 "lib/buildOCPParser.mly"
  ( [] )
# 267 "lib/buildOCPParser.ml"
               : 'statements))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'statement) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'statements) in
    Obj.repr(
# 68 "lib/buildOCPParser.mly"
                       ( _1 :: _2 )
# 275 "lib/buildOCPParser.ml"
               : 'statements))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'statements) in
    Obj.repr(
# 69 "lib/buildOCPParser.mly"
                  ( _2 )
# 282 "lib/buildOCPParser.ml"
               : 'statements))
; (fun __caml_parser_env ->
    Obj.repr(
# 73 "lib/buildOCPParser.mly"
          ( ProjectProgram )
# 288 "lib/buildOCPParser.ml"
               : 'package_type))
; (fun __caml_parser_env ->
    Obj.repr(
# 74 "lib/buildOCPParser.mly"
          ( ProjectLibrary )
# 294 "lib/buildOCPParser.ml"
               : 'package_type))
; (fun __caml_parser_env ->
    Obj.repr(
# 75 "lib/buildOCPParser.mly"
          ( ProjectObjects )
# 300 "lib/buildOCPParser.ml"
               : 'package_type))
; (fun __caml_parser_env ->
    let _3 = (Parsing.peek_val __caml_parser_env 2 : string) in
    let _4 = (Parsing.peek_val __caml_parser_env 1 : 'options) in
    Obj.repr(
# 79 "lib/buildOCPParser.mly"
                                  ( StmtDefineConfig (_3, _4) )
# 308 "lib/buildOCPParser.ml"
               : 'statement))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 3 : 'package_type) in
    let _3 = (Parsing.peek_val __caml_parser_env 2 : string) in
    let _4 = (Parsing.peek_val __caml_parser_env 1 : 'simple_statements) in
    Obj.repr(
# 80 "lib/buildOCPParser.mly"
                                                  ( StmtDefinePackage (_2, _3, _4) )
# 317 "lib/buildOCPParser.ml"
               : 'statement))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 1 : 'statements) in
    Obj.repr(
# 81 "lib/buildOCPParser.mly"
                       ( StmtBlock _2 )
# 324 "lib/buildOCPParser.ml"
               : 'statement))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 82 "lib/buildOCPParser.mly"
                 ( StmtInclude _2 )
# 331 "lib/buildOCPParser.ml"
               : 'statement))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'simple_statement) in
    Obj.repr(
# 83 "lib/buildOCPParser.mly"
                   ( _1 )
# 338 "lib/buildOCPParser.ml"
               : 'statement))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 5 : string) in
    let _5 = (Parsing.peek_val __caml_parser_env 2 : 'package_type) in
    let _6 = (Parsing.peek_val __caml_parser_env 1 : 'simple_statements) in
    Obj.repr(
# 86 "lib/buildOCPParser.mly"
                                                             ( StmtDefinePackage (_5, _2, _6) )
# 347 "lib/buildOCPParser.ml"
               : 'statement))
; (fun __caml_parser_env ->
    Obj.repr(
# 90 "lib/buildOCPParser.mly"
  ( [] )
# 353 "lib/buildOCPParser.ml"
               : 'simple_statements))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'simple_statement) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'simple_statements) in
    Obj.repr(
# 91 "lib/buildOCPParser.mly"
                                     ( _1 :: _2 )
# 361 "lib/buildOCPParser.ml"
               : 'simple_statements))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'simple_statements) in
    Obj.repr(
# 92 "lib/buildOCPParser.mly"
                         ( _2 )
# 368 "lib/buildOCPParser.ml"
               : 'simple_statements))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'option) in
    Obj.repr(
# 96 "lib/buildOCPParser.mly"
         ( StmtOption _1 )
# 375 "lib/buildOCPParser.ml"
               : 'simple_statement))
; (fun __caml_parser_env ->
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'list_of_files) in
    Obj.repr(
# 97 "lib/buildOCPParser.mly"
                            ( StmtFilesSet _3 )
# 382 "lib/buildOCPParser.ml"
               : 'simple_statement))
; (fun __caml_parser_env ->
    let _3 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 98 "lib/buildOCPParser.mly"
                    ( StmtFilesSet [_3, []] )
# 389 "lib/buildOCPParser.ml"
               : 'simple_statement))
; (fun __caml_parser_env ->
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'list_of_files) in
    Obj.repr(
# 99 "lib/buildOCPParser.mly"
                                ( StmtFilesAppend _3 )
# 396 "lib/buildOCPParser.ml"
               : 'simple_statement))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'list_of_strings) in
    Obj.repr(
# 100 "lib/buildOCPParser.mly"
                           ( StmtRequiresAppend _2 )
# 403 "lib/buildOCPParser.ml"
               : 'simple_statement))
; (fun __caml_parser_env ->
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'list_of_strings) in
    Obj.repr(
# 102 "lib/buildOCPParser.mly"
                                 ( StmtRequiresAppend _3 )
# 410 "lib/buildOCPParser.ml"
               : 'simple_statement))
; (fun __caml_parser_env ->
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'list_of_strings) in
    Obj.repr(
# 103 "lib/buildOCPParser.mly"
                                     ( StmtRequiresAppend _3 )
# 417 "lib/buildOCPParser.ml"
               : 'simple_statement))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 107 "lib/buildOCPParser.mly"
             ( OptionConfigSet _2 )
# 424 "lib/buildOCPParser.ml"
               : 'option))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : string) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 108 "lib/buildOCPParser.mly"
                     ( OptionListSet (_1,[_3]) )
# 432 "lib/buildOCPParser.ml"
               : 'option))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : string) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 109 "lib/buildOCPParser.mly"
                         ( OptionListAppend (_1,[_3]) )
# 440 "lib/buildOCPParser.ml"
               : 'option))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : string) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 110 "lib/buildOCPParser.mly"
                          ( OptionListRemove (_1,[_3]) )
# 448 "lib/buildOCPParser.ml"
               : 'option))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : string) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'list_of_strings) in
    Obj.repr(
# 111 "lib/buildOCPParser.mly"
                              ( OptionListSet (_1,_3) )
# 456 "lib/buildOCPParser.ml"
               : 'option))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : string) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'list_of_strings) in
    Obj.repr(
# 112 "lib/buildOCPParser.mly"
                                  ( OptionListAppend (_1, _3) )
# 464 "lib/buildOCPParser.ml"
               : 'option))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : string) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'list_of_strings) in
    Obj.repr(
# 113 "lib/buildOCPParser.mly"
                                   ( OptionListRemove (_1, _3) )
# 472 "lib/buildOCPParser.ml"
               : 'option))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : string) in
    Obj.repr(
# 114 "lib/buildOCPParser.mly"
                   ( OptionBoolSet (_1, true) )
# 479 "lib/buildOCPParser.ml"
               : 'option))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : string) in
    Obj.repr(
# 115 "lib/buildOCPParser.mly"
                    ( OptionBoolSet (_1, false) )
# 486 "lib/buildOCPParser.ml"
               : 'option))
; (fun __caml_parser_env ->
    Obj.repr(
# 119 "lib/buildOCPParser.mly"
  ( [] )
# 492 "lib/buildOCPParser.ml"
               : 'options))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'option) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'options) in
    Obj.repr(
# 120 "lib/buildOCPParser.mly"
                 ( _1 :: _2 )
# 500 "lib/buildOCPParser.ml"
               : 'options))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'options) in
    Obj.repr(
# 121 "lib/buildOCPParser.mly"
               ( _2 )
# 507 "lib/buildOCPParser.ml"
               : 'options))
; (fun __caml_parser_env ->
    Obj.repr(
# 125 "lib/buildOCPParser.mly"
                         ( [] )
# 513 "lib/buildOCPParser.ml"
               : 'list_of_options))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 1 : 'options) in
    Obj.repr(
# 126 "lib/buildOCPParser.mly"
                         ( _2 )
# 520 "lib/buildOCPParser.ml"
               : 'list_of_options))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 1 : 'strings) in
    Obj.repr(
# 130 "lib/buildOCPParser.mly"
                            ( _2 )
# 527 "lib/buildOCPParser.ml"
               : 'list_of_strings))
; (fun __caml_parser_env ->
    Obj.repr(
# 134 "lib/buildOCPParser.mly"
 ( [] )
# 533 "lib/buildOCPParser.ml"
               : 'strings))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : string) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'strings) in
    Obj.repr(
# 135 "lib/buildOCPParser.mly"
                 ( _1 :: _2 )
# 541 "lib/buildOCPParser.ml"
               : 'strings))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : string) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'strings) in
    Obj.repr(
# 136 "lib/buildOCPParser.mly"
                ( _1 :: _2 )
# 549 "lib/buildOCPParser.ml"
               : 'strings))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'strings) in
    Obj.repr(
# 137 "lib/buildOCPParser.mly"
               ( _2 )
# 556 "lib/buildOCPParser.ml"
               : 'strings))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 1 : 'files) in
    Obj.repr(
# 141 "lib/buildOCPParser.mly"
                          ( _2 )
# 563 "lib/buildOCPParser.ml"
               : 'list_of_files))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 145 "lib/buildOCPParser.mly"
              ( _2 )
# 570 "lib/buildOCPParser.ml"
               : 'packer))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 146 "lib/buildOCPParser.mly"
              ( let s = _2 in s.[0] <- Char.lowercase s.[0]; s ^ ".ml" )
# 577 "lib/buildOCPParser.ml"
               : 'packer))
; (fun __caml_parser_env ->
    Obj.repr(
# 150 "lib/buildOCPParser.mly"
 ( [] )
# 583 "lib/buildOCPParser.ml"
               : 'files))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : string) in
    let _2 = (Parsing.peek_val __caml_parser_env 1 : 'list_of_options) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'files) in
    Obj.repr(
# 151 "lib/buildOCPParser.mly"
                               ( (_1, _2) :: _3 )
# 592 "lib/buildOCPParser.ml"
               : 'files))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'files) in
    Obj.repr(
# 152 "lib/buildOCPParser.mly"
             ( _2 )
# 599 "lib/buildOCPParser.ml"
               : 'files))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 3 : 'list_of_options) in
    let _3 = (Parsing.peek_val __caml_parser_env 2 : 'files) in
    let _5 = (Parsing.peek_val __caml_parser_env 0 : 'files) in
    Obj.repr(
# 154 "lib/buildOCPParser.mly"
   ( let shared_options = _2 in
     let inner_files = _3 in
     let outter_files = _5 in
     let inner_files =
       List.map (fun (file, file_options) ->
	 (file, shared_options @ file_options)
       ) inner_files in
     inner_files @ outter_files
   )
# 616 "lib/buildOCPParser.ml"
               : 'files))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 4 : 'packer) in
    let _2 = (Parsing.peek_val __caml_parser_env 3 : 'list_of_options) in
    let _3 = (Parsing.peek_val __caml_parser_env 2 : 'list_of_files) in
    let _4 = (Parsing.peek_val __caml_parser_env 1 : 'list_of_options) in
    let _5 = (Parsing.peek_val __caml_parser_env 0 : 'files) in
    Obj.repr(
# 163 "lib/buildOCPParser.mly"
                                                             (
  let packname = _1 in
  let pack_options1 = _2 in
  let files = _3 in
  let pack_options2 = _4 in
  let other_files = _5 in
  let pack_options = pack_options1 @ pack_options2 in

  let packmodname = BuildOCPTypes.modname_of_fullname packname in

  let modnames = ref [] in
  let packed_files =
    List.map (fun (file, file_options) ->
      begin
        match file_options with
            OptionListAppend ( "packed", _ ) :: _ -> ()
          | _ ->
            modnames := Filename.basename file :: !modnames
      end;
      (file, OptionListAppend ("packed", [packmodname]) :: pack_options @ file_options)
  ) files;
  in
  packed_files @
    [ packname, OptionListSet ("pack", List.rev !modnames) :: pack_options] @
    other_files
)
# 652 "lib/buildOCPParser.ml"
               : 'files))
(* Entry main *)
; (fun __caml_parser_env -> raise (Parsing.YYexit (Parsing.peek_val __caml_parser_env 0)))
|]
let yytables =
  { Parsing.actions=yyact;
    Parsing.transl_const=yytransl_const;
    Parsing.transl_block=yytransl_block;
    Parsing.lhs=yylhs;
    Parsing.len=yylen;
    Parsing.defred=yydefred;
    Parsing.dgoto=yydgoto;
    Parsing.sindex=yysindex;
    Parsing.rindex=yyrindex;
    Parsing.gindex=yygindex;
    Parsing.tablesize=yytablesize;
    Parsing.table=yytable;
    Parsing.check=yycheck;
    Parsing.error_function=parse_error;
    Parsing.names_const=yynames_const;
    Parsing.names_block=yynames_block }
let main (lexfun : Lexing.lexbuf -> token) (lexbuf : Lexing.lexbuf) =
   (Parsing.yyparse yytables 1 lexfun lexbuf : BuildOCPTypes.statement list)
;;
