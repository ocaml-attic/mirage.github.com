#!/bin/bash

ocaml discover.ml