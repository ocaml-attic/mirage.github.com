
let _ = 
  [
    s_ "hello world!\n";
    s_ "goodbye world!
";
    s_ "goodby world 2!\
      ";
    s_ "and then\tbye-bye";
  ]
;;


