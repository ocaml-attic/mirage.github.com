(* Just check that the extension and library load without error.
 * $Id: test_01_load.ml 187 2012-01-17 12:39:09Z richard.wm.jones@gmail.com $
 *)

let _ = Bitstring.extract_bit
