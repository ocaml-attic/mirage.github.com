
value value_of_mousebutton_state(Uint8 state);
