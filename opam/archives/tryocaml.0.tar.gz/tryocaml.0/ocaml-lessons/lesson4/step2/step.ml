fun input output ->
  find_in  "val capitalize : char -> char =" output
