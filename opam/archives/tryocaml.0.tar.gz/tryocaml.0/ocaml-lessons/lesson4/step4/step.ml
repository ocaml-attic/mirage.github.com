fun input output ->
  find_in  "val head_head : 'a list list -> 'a =" output
