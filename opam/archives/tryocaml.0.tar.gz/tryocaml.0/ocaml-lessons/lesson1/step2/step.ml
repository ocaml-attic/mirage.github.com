fun input output ->
  find_in  "- : string array =" output
