fun _ output ->
  find_in  "- : int * int =" output
