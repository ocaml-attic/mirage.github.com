double x;

void f() {
double y;
/*0*/	y = x+1.e291;
/*1*/	y = x+1.e292;
/*2*/	y = x+x;
/*3*/	y = x+1e-6;
}
