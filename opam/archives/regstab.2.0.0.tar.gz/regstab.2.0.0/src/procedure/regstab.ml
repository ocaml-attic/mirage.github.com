(** Main loop driving the strategy.
 * Main dependency: {!ExpandNode}.
 *)
open Softcore open Helpers

(** Signature. *)
module type S =
  sig
    (** {6 Ancestors} *)

    (** [ExpandNode] module we rely on. *)
    module ExpandNode : ExpandNode.S
    
    (** The type of atomic schema sets we rely on. *)
    type atomic_schset = ExpandNode.atomic_schset

    (** The type of nodes we rely on. *)
    type node = ExpandNode.node

    (** {6 Provided functions and types} *)

    (** The type of the result:
      * either we have a satisfiable schema, with a set of atomic schemas,
      * (note that this set is not, in general, enough to produce a model;
      * the ``WITH_MODEL'' version of each module should be used for this),
      * or an unsatisfiable schema with the root of the corresponding tableau
      * (note though, that the links from the root to its children do exist only in cases where the proof is actually computed).
      *)
    type result = Sat of atomic_schset | Unsat of node

    (** Required information to generate the output. *)
    module O : OUTPUT_INFO

    (** Main function: takes a constraint and a schema, and outputs a string and a result.
     * The result provides the essential information, but the string provides additional info,
     * like statistics, number of used lemmas, etc. *)
    val regstab : cstr:Constraint.t -> Schema.t -> O.S.t * result

    (** Used only internally (don't remember why it is needed to be honest...). *)
    module InternalLemmas : Lemmas.S 
  end

(** Make a module of signature {!S} out of an ``expand node'' module (of signature {!ExpandNode.S}).
 * A module of signature {!OUTPUT_INFO} is also required for the output. *)
module Make_std (O : OUTPUT_INFO) (E : ExpandNode.S) : S with module ExpandNode = E =
  struct
    (** Inheriting types and modules from {!E}: *)
    module ExpandNode = E
    module S = O.S
    module O = O
    module N = E.Lemmas.Node
    module A = N.RuleApplication.SchemaSet.AtomicSchemaSet
    module InternalLemmas = E.Lemmas

    type node = N.t
    type atomic_schset = A.t

    (** (...) see {!S}. *)
    (**/**)
    type result = Sat of A.t | Unsat of E.node
    let is_unsat = function Sat _ -> false | Unsat _ -> true

    let main ~handle ~cstr sch =
      let q = Queue.create () in
      let root = N.init ~cstr sch in
      Queue.push root q;
      let append = List.iter ~f:(fun x -> Queue.push x q) in
      let current_result = ref (Unsat root) in
      while not (Queue.is_empty q) && is_unsat !current_result do
        let current = Queue.pop q in
        match handle current with
        |E.Satisfiable abk -> current_result := Sat abk
        |E.Nodes nodes -> append nodes
      done;
      S.of_string ("\n" ^ (match !current_result with Sat _ -> "" | Unsat _ -> "UN") ^ "SATISFIABLE\n"), 
      !current_result

    let regstab ~cstr sch =
      match Schema.has_iterations sch with
      |`No -> main ~handle:E.handle_without_iteration ~cstr sch
      |`Yes bounds -> 
          let lower = Bounds.lower_of bounds in
          let upper_shift = Bounds.upper_shift_of bounds in
        let empty_cstr = Constraint.bounds_constraint ~lower ~upper_shift Inequality.Gt in
        let non_empty_cstr = Constraint.bounds_constraint ~lower ~upper_shift Inequality.Le in
        main ~handle:(E.handle_with_iteration ~bounds ~empty_cstr ~non_empty_cstr) ~cstr sch
  end

(** Extends a module of signature {!S} with model printing.
 * An atomic schema set of signature {!AtomicSchemaSet.WITH_MODEL} is thus required.
 * Of course, types must be coherent with the inherited {!AtomicSchemaSet} module
 * (ideally we would not need to provide the same {!AtomicSchemaSet} module again since it is already inherited,
 * but the inherited module has signature {!AtomicSchemaSet.S} and not {!AtomicSchemaSet.WITH_MODEL},
 * so the simplest way is just to pass the same module again and ensure that types are the same).
 * In addition, a module is required that contains variables to be excluded from the displayed model.
 *)
module Extend_with_model 
  (R : S)
  (A : AtomicSchemaSet.WITH_MODEL with type t = R.atomic_schset)
  (X : sig val excluded_variables : Proposition.t list end)
  : S with module ExpandNode = R.ExpandNode
  =
  struct
    (**/**) 
    include R
    module S = O.S
    module MOutput = Model.Output(S)
    let (^) = S.(^)
    let regstab ~cstr sch = 
      let (s,res) = regstab ~cstr sch in
      (s ^ match res with Unsat _ -> S.empty | Sat b -> 
        MOutput.to_string ~exclude:X.excluded_variables ~sch ~param:O.parameter ~var:O.bound_variable (A.Model.retrieve b)), res
  end

(** Extends a module of signature {!S} with stats printing.
 * A rule application module of signature {!RuleApplication.WITH_STATS}
 * and a lemmas module of signature {!Lemmas.WITH_STATS} are thus required.
 * Of course, types must be coherent with the inherited {!RuleApplication} and {!Lemmas} modules
 * (ideally we would not need to provide those modules again since they are already inherited,
 * but those inherited modules have standard signatures and not [WITH_STATS] signatures;
 * so the simplest way is just to pass the same modules again and ensure that types are the same).
 *)
module Extend_with_stats (R : S) (RA : RuleApplication.WITH_STATS) (L : Lemmas.WITH_STATS) 
  : S with module ExpandNode = R.ExpandNode =
  struct
    (**/**)
    include R
    module S = O.S

    let (^) = S.(^)
    let (^+) s x = s ^ S.of_int x
    let (!) = S.of_string

    let regstab ~cstr sch = 
      let (s,res) = R.regstab ~cstr sch in
      (s ^ S.eol ^ S.eol ^ S.concat ~sep:S.eol ([
        !"Applications of tableau rules:";
        S.wedge ^ !": " ^+ RA.Stats.conj ();
        S.vee   ^ !": " ^+ RA.Stats.disj ();
        S.oplus ^ !": " ^+ RA.Stats.xor ();
        S.equiv ^ !": " ^+ RA.Stats.equ ();
        S.imply ^ !": " ^+ RA.Stats.imp ();
        !"-------";
        !"Total propositional rules: " ^+ RA.Stats.conj () + RA.Stats.disj () + RA.Stats.xor () + RA.Stats.equ () + RA.Stats.imp ();
        !"Iteration rules: " ^+ RA.Stats.unfolds ();
        S.empty;
        !"Number of looping leaves:       " ^+ L.Stats.loops ();
        !"Number of lemmas:               " ^+ L.Stats.lemmas ();
        !"Number of actually used lemmas: " ^+ L.Stats.used_lemmas ();
      ])), res
  end

(** Additional parameters to provide in case the user wants the proof to be generated. *)
module type PROOF_PARAMS = sig 
  (** File in which store the proof. *)
  val file : string 

  (** There are two file formats for proofs:
   * a ``machine oriented'' one (see {{:../../tools/regularproof.dtd}regularproof.dtd}),
   * and a ``human oriented'' one (see {{:../../tools/prooftrees.dtd}prooftrees.dtd}). *)
  val machine_oriented : bool

  (** The output XML can be indented and (slightly) nicely put in order to be more readable by humans, or it can be ugly.
   * If [human_xml=true] then it is nicely put.
   *)
  val human_xml : bool
end

(** Extends a module of signature {!S} with proof generating.
 * A node module of signature {!Node.WITH_PROOF} is thus required.
 * Of course, types must be coherent with the inherited {!Node} module
 * (ideally we would not need to provide this module again since it is already inherited,
 * but this inherited module has a standard signature and not a [WITH_PROOF] one;
 * so the simplest way is just to pass the same module again and ensure that types are the same).
 * In addition we also require a {!PROOF_PARAMS} module in order to have all the needed information.
 *)
module Extend_with_proof 
  (R : S)
  (N : Node.WITH_PROOF with type t = R.node and module RuleApplication = R.ExpandNode.Lemmas.Node.RuleApplication)
  (P : PROOF_PARAMS) 
  : S with module ExpandNode = R.ExpandNode =
  struct
    (**/**)
    include R
    module S = O.S
    module H = Human.Output(S)
    module PO = Proof.Output(S)
    module X = XML(S)

    let regstab ~cstr sch =
      let s,res = R.regstab ~cstr sch in
      match res with
      |Sat _ -> s,res
      |Unsat r ->
          let proof = PreProof.to_proof Proof.({
            root = N.Proof.get_proof_node r;
            parameter = O.parameter;
            bound_variable = O.bound_variable;
            bounds = O.bounds;
          }) in
          try
            let ch = open_out P.file in
            let contents = if P.machine_oriented then PO.to_xml proof else H.proof_to_xml (Proof.to_human proof) in
            print_string "Writing proof to XML file...";
            flush stdout;
            let doctype = S.of_string (if P.machine_oriented then "regularproof" else "prooftrees") in
            X.output ~human:P.human_xml ~ch ~doctype contents;
            close_out ch;
            print_endline "done";
            s,res
          with Sys_error err ->
            let msg = "The proof could not be written due to a system error: " ^ err in
            S.(s ^ eol ^ eol ^ of_string msg), res
  end

(**/**)
let internal_display_msg = " (as stored internally, i.e. bounds and variable names might slightly differ from your input)"
(**/**)

(** Extends a module of signature {!S} with used lemmas display.
 * A lemmas module providing a [used_lemmas] value is also required.
 * Of course, types must be coherent with the inherited {!Lemmas} module
 * (ideally we would not need to provide this module again since it is already inherited,
 * but this inherited module has a standard signature and does not provide the [used_lemmas] value,
 * so the simplest way is just to pass the same module again and ensure that types are the same).
 *)
module Extend_with_used_lemmas (R : S) (L : sig include Lemmas.S val used_lemmas : unit -> unit Lemmas.Lemma_table.t end)
  : S with module ExpandNode = R.ExpandNode =
  struct
    (**/**)
    include R
    module S = O.S
    open S
    module LO = Lemmas.T.Output(O)
    let (!) = S.of_string
    let regstab ~cstr sch =
      let (s,res) = R.regstab ~cstr sch in
      let used_lemmas = L.used_lemmas () in
      (if Lemmas.T.is_empty used_lemmas 
      then s ^ !"\nNo lemma used in the deduction.\n"
      else s ^ !"\n\nLemmas used in the deduction" ^ !internal_display_msg ^ !":\n" ^ LO.to_string used_lemmas) ^ S.eol
      , res
  end

(** Extends a module of signature {!S} with all lemmas display. *)
module Extend_with_all_lemmas_printing (R : S) : S with module ExpandNode = R.ExpandNode =
  struct
    (**/**)
    include R
    module S = O.S
    open S
    let (!) = S.of_string
    module LO = InternalLemmas.Output(O) (* that's the only location where we use InternalLemmas *)
    let regstab ~cstr sch =
      let (s,res) = R.regstab ~cstr sch in
      s ^ !"\n\nLemma database" ^ !internal_display_msg ^ !":\n" ^ LO.to_string () ^ S.eol, res
  end

(** Extends a module of signature {!S} with an expectation about the result.
 * This expectation is provided with a module [Expectation] giving the expected result.
 *)
module Extend_with_expectation (R : S) (Expectation : sig val expected : [ `Sat | `Unsat ] end) : S with module ExpandNode = R.ExpandNode =
  struct
    (**/**)
    include R
    module S = O.S
    open S
    let regstab ~cstr sch =
      let (s,res) = R.regstab ~cstr sch in
      (s ^ 
        match res, Expectation.expected with
        |R.Sat _,`Sat | R.Unsat _,`Unsat -> S.empty
        |_ -> S.of_string "ERROR: EXPECTED TO BE " ^ S.of_string (match Expectation.expected with `Sat -> "SAT" | `Unsat -> "UNSAT"))
      , res
  end

(** Extends a module of signature {!S} with verbosity.
 * A module giving the kind of strings is required.
 *)
module Extend_with_verbose (R : S) (S : String.S) : S with module ExpandNode = R.ExpandNode =
  struct
    (**/**)
    include R
    module S = O.S
    open S
    module H = Human.Output(S)
    let regstab ~cstr sch =
      let sch_string = H.schema_to_string (Schema.to_human ~param:O.parameter ~var:O.bound_variable sch) in
      S.print_double_endlines (S.of_string "\nParsed conjecture (variables might differ from your input):\n" ^ sch_string);
      let cstr_string = H.cstr_to_string (Constraint.to_human ~var:O.parameter cstr) in
      if not (Constraint.is_true cstr) then S.print_double_endlines (S.of_string "Considered constraint: " ^ cstr_string);
      R.regstab ~cstr sch
  end
