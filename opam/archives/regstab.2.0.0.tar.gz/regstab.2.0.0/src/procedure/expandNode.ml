(** Main implementation of the strategy.
 * Main dependency: {!Lemmas}.
 *)
open Softcore open Helpers

(** Signature. *)
module type S =
  sig
    (** {6 Ancestors} *)

    (** [Lemmas] module we rely on. *)
    module Lemmas : Lemmas.S

    (** The type of atomic schema sets we rely on. *)
    type atomic_schset = Lemmas.Node.atomic_schset

    (** The type of nodes we rely on. *)
    type node = Lemmas.Node.t

    (** {6 Provided functions and types} *)

    (** The type of the result: either a satisfiable set of atomic schemata (in case of satisfiability),
     * or a list of non-closed nodes to go on with (empty means unsatisfiability). *)
    type result = Satisfiable of atomic_schset | Nodes of node list

    (** Handle a node whose set of schemas does contain some iteration. *)
    val handle_with_iteration : bounds:Bounds.t -> empty_cstr:Constraint.t -> non_empty_cstr:Constraint.t -> node -> result

    (** Handle a node whose set of schemas does not contain any iteration.
     * No bounds nor constraint to deal with in this case. *)
    val handle_without_iteration : node -> result
  end

(** Make a module of signature {!S} out of a lemma database module (of signature {!Lemmas.S}). *)
module Make_std (L : Lemmas.S) : S with module Lemmas = L =
  struct
    (** Inheriting types and modules from {!L}: *)
    module Lemmas = L
    module N = L.Node
    module R = N.RuleApplication
    module B = R.SchemaSet
    module A = B.AtomicSchemaSet
    type atomic_schset = A.t
    type node = N.t

    (** (...) see {!S}. *)
    (**/**)
    open Node
    open SchemaSet

    type result = Satisfiable of A.t | Nodes of N.t list
    module CoN = ClosedOrNot

    let filtered_nodes xs = Nodes (List.filter_map xs ~f:CoN.(function Closed _ -> None | Non_closed n -> Some n))

    (* [k] is the continuation to apply when we reach an atomic pending node. This happens iff the node *does* contain iterations. *)
    let common ~purify ~k n = 
      match N.get_schset n with
      |AtomicOrNot.Atomic schs -> k ~node:n schs
      |AtomicOrNot.Non_atomic schs ->
        match B.pick_non_atomic schs with
        |None when B.contains_iteration schs -> purify ~node:n (B.to_atomic schs)
        |None -> Satisfiable (B.to_atomic schs)
        |Some(na,schs) ->
          match na with
          |`Bot -> Nodes (N.of_bot_result ~parent:n (R.Bot.rule ~schs))
          |`Top -> Nodes [ N.of_top_result ~parent:n (R.Top.rule ~schs) ]
          |`Op(con,s1,s2) ->
              match Connective.destruct con with
              |`And -> filtered_nodes [ N.of_and_result ~parent:n (R.And.rule ~schs s1 s2) ]
              |(`Or|`Xor|`Equiv|`Imply) as con ->
                let f = R.Split.(match con with `Or -> disj | `Xor -> xor | `Equiv -> equiv | `Imply -> imply) in
                filtered_nodes (List.of_pair (N.of_split_result ~parent:n (f ~schs s1 s2)))

    let handle_without_iteration = common ~purify:(fun ~node:_ _ -> assert false) ~k:(fun ~node _ -> assert false)

    let handle_with_iteration ~bounds ~empty_cstr ~non_empty_cstr =
      common ~purify:(fun ~node schs -> Nodes [ N.of_pur_result ~parent:node (R.Pur.rule ~bounds ~schs) ]) 
        ~k:(fun ~node schs ->
          let lemma = A.to_std schs in
          match L.find lemma with
          |Some info -> Nodes (N.of_looping_info ~parent:node info)
          |None ->
            L.add lemma ~info:(N.get_looping_info node);
            match N.of_unfold_result ~parent:node (R.Unfold.rule ~empty_cstr ~non_empty_cstr ~schs) with
            |`Sat a -> Satisfiable a
            |`Closed -> Nodes []
            |`Neither n -> Nodes [n])

    let rec handle_with_iteration_star ~bounds ~empty_cstr ~non_empty_cstr n =
      match handle_with_iteration ~bounds ~empty_cstr ~non_empty_cstr n with
      |Satisfiable _ as x -> x
      |Nodes ([] | _::_::_) as x -> x
      |Nodes [n'] -> handle_with_iteration_star ~bounds ~empty_cstr ~non_empty_cstr n'

    let handle_with_iteration = handle_with_iteration_star
  end
