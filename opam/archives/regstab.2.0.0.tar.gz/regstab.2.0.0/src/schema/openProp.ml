(** A datatype which is common to all types with a propositional structure
 * (namely a type involving ⊤, ⊥, literals, and the usual binary operators).
 * In our case this means {!Flat} and {!Prop}.
 * The "open" in "openProp" refers to the fact that the type is open
 * (i.e. it is not recursive but instead has a type parameter
 * - which can be used to get a recursive version of the open type,
 * as is done in {!Prop}).
 *)
open Softcore

module Exposed =
  struct
    (** Non atomic formulas, i.e. formulas that are not literals
     * (note that the usual definition of an atom should also exclude ⊤ and ⊥, which we do not do here)
     *)
    type 'a non_atomic = [ `Op  of Connective.t * 'a * 'a | `Top | `Bot ]

    (** The open type. *)
    type 'a t = [ `Lit of Literal.t | 'a non_atomic ]

    (** The closed type. *)
    type prop = prop t

    (** {6 Comparisons} *)

    let equal equal_rec s1 s2 =
      match s1,s2 with
      |`Top,`Top | `Bot,`Bot           -> true
      |`Lit l1, `Lit l2                -> Literal.equal l1 l2
      |`Op(op1,s1,s1'),`Op(op2,s2,s2') -> Connective.equal op1 op2 && equal_rec s1 s2 && equal_rec s1' s2'
      |`Top,_ |`Bot,_ |`Lit _,_ |`Op _,_ -> false

    let total_compare total_compare_rec (s1:'a t) s2 =
      match s1,s2 with
      |`Lit l1, `Lit l2                -> Literal.compare l1 l2
      |`Op(op1,s1,s1'),`Op(op2,s2,s2') -> 
          let opcmp = Connective.compare op1 op2 in 
          if opcmp <> 0 then opcmp else
            (let scmp = total_compare_rec s1 s2 in
            if scmp <> 0 then scmp else total_compare_rec s1' s2')
      |`Top,`Top | `Bot,`Bot -> 0
      |`Top,_ -> -1
      |_,`Top  -> 1
      |`Bot,_   -> -1
      |_,`Bot   -> 1
      |`Lit _,_ -> -1
      |_,`Lit _ -> 1
      |`Op _,_  -> -1

    (** {6 Useful operations} *)

    let opposite opposite_rec = function
      |`Top -> `Bot
      |`Bot -> `Top
      |`Lit l -> `Lit(Literal.opposite l)
      |`Op(op,s1,s2) ->
          let op',f1,f2 = Connective.opposite op ~opposite_formula:opposite_rec in
          `Op(op',f1 s1,f2 s2)

    let combine ~op = function
      |[]   -> Connective.Big.neutral op
      |[sk] -> sk
      |sks  -> List.reduce ~f:(fun sk1 sk2 -> `Op(Connective.of_big op,sk1,sk2)) sks

    let algebraic_simplification algebraic_simplification_rec opposite_neutral = function
      |`Top | `Bot | `Lit _ as x -> x
      |`Op(op,s1,s2) -> 
            let s1 = algebraic_simplification_rec s1 in
            let s2 = algebraic_simplification_rec s2 in
            match Connective.neutral_simplification op ~left:s1 ~opposite_neutral with
            |Some f -> f s2 (* if a simplification is found then apply it *)
            |None ->
                match Connective.neutral_simplification op ~left:s2 ~opposite_neutral with 
                |None -> `Op(op,s1,s2) 
                |Some f -> f s1

    let compute compute_rec ~n = function
      |`Lit l -> `Lit (Literal.compute l n)
      |`Op(op,s1,s2) -> `Op(op, compute_rec ~n s1, compute_rec ~n s2)
      |(`Top | `Bot) as x -> x

    let rec substitute_variable substitute_variable_rec ~by = function
      |`Lit l        -> `Lit(Literal.substitute_variable ~by l)
      |`Op(op,s1,s2) -> `Op(op,substitute_variable_rec ~by s1,substitute_variable_rec ~by s2)
      |`Top          -> `Top
      |`Bot          -> `Bot

    let rec shift shift_rec ?by = function
      |`Lit l        -> `Lit(Literal.shift ?by l)
      |`Op(op,s1,s2) -> `Op(op, shift_rec ?by s1, shift_rec ?by s2)
      |`Top          -> `Top
      |`Bot          -> `Bot

    (** {6 Conversions from/to human schemas} *)

    module H = Human
    let to_human to_human_rec ~var = function
      |`Top -> H.Top
      |`Bot -> H.Bot
      |`Lit l -> H.Lit (Literal.to_human ~var l)
      |`Op(con,s1,s2) -> H.Op(Connective.to_human con, to_human_rec s1, to_human_rec s2)

    let of_human of_human_rec ~iteration_case = function
      |H.Op(con,s1,s2) -> `Op(Connective.of_human con, of_human_rec s1, of_human_rec s2)
      |H.Lit l -> `Lit(Literal.of_human l)
      |H.It it -> iteration_case it
      |H.Top -> `Top
      |H.Bot -> `Bot
  end

include Exposed
