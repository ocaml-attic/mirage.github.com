(** Datatype and operations related to polarities. A polarity is either "Positive" or "Negative". *)
open Softcore

(** Signature of the module. *)
module type S =
  sig
    (** Type of polarities. *)
    type t

    (** {6 Comparisons} *)

    val equal : t -> t -> bool
    val compare : t -> t -> int

    (** {6 Constructors} *)

    val pos : t
    val neg : t

    (** {6 Destructors} *)

    val is_pos : t -> bool
    val is_neg : t -> bool
    
    (** {6 Useful operations} *)

    val opposite : t -> t

    (** {6 Conversions from/to human bounds} *)

    val to_human : t -> Human.polarity
    val of_human : Human.polarity -> t

    (** {6 Output to XML} *)
    (** Note: the output depends on the wanted encoding for strings, hence the functor. *)
    module Output : functor (S : String.S) -> sig val to_xml : t -> XML(S).tag end
  end

(**/**)
module Exposed =
  struct
    type t = Human.polarity
    open Human
    let to_human = ident
    let of_human = ident
    let opposite = Human.complementary_pol
    let is_pos = function Pos -> true | Neg -> false
    let is_neg = function Pos -> false | Neg -> true
    let equal p1 p2 = match p1,p2 with Pos,Pos | Neg,Neg -> true | _ -> false
    let compare p1 p2 = match p1,p2 with Pos,Neg -> 1 | Neg,Pos -> -1 | _ -> 0
    let pos = Pos
    let neg = Neg
    module Output (S : String.S) =
      struct
        let to_xml = S.of_string <|| function Pos -> "pos_atom" | Neg -> "neg_atom"
      end
  end

include (Exposed : S)
