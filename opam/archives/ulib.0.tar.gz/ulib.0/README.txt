(* OASIS_START *)
(* DO NOT EDIT (digest: 74f9915bbb566481a874c0ccb64ba832) *)
This is the README file for the ulib distribution.

A feather weight Unicode library for OCaml

See the files INSTALL.txt for building and installation instructions. 


(* OASIS_STOP *)
