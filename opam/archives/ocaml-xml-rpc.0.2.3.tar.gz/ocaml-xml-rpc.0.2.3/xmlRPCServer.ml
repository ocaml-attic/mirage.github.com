(*
    Ocaml XML-RPC support.
    Copyright (C) 2004 Shawn Wagner <raevnos@pennmush.org>

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*)
open Netencoding
open Pxp_yacc
open Pxp_document
open Pxp_types

let server = "Ocaml-XML-RPC/" ^ XmlRPCClient.client_version ^ " (" ^ Sys.os_type ^ ")"

exception Error of string * int

class type source =
object 
  method get_request: unit -> string
  method send_reply: string -> unit
end

type resp = [ `Value of XmlRPCTypes.t | `Fault of string * int ]

type t = 
    { handler: source;
      methods: (string, XmlRPCTypes.t array -> XmlRPCTypes.t) Hashtbl.t;
    }

let make s =
  { handler = s;
    methods = Hashtbl.create 33;
  }

let register_callback hnd name callback =
  Hashtbl.add hnd.methods name callback

let remove_callback hnd name =
  Hashtbl.remove hnd.methods name

let is_handled hnd name = 
  Hashtbl.mem hnd.methods name

let list_functions hnd = 
  let keys = ref [] in
    Hashtbl.iter (fun key _ -> keys := key :: !keys) hnd.methods;
    !keys

let xml_version = "<?xml version=\"1.0\"?>"

let transform_dtd d = XmlRPCDtd.parsed_server_dtd ()

let parse_param node =
  let value = List.hd node#sub_nodes in
    XmlRPCTypes.parse_value value

let handle_request h xml =
  let req =
    parse_document_entity ~transform_dtd default_config
      (from_string xml) default_spec in
  let req2 = req#root#sub_nodes in
  let name = (List.hd req2)#data 
  and params = List.hd (List.tl req2) in
  let args = Array.of_list
	       (List.map parse_param params#sub_nodes) in
    try
      let fn = Hashtbl.find h.methods name in
	`Value (fn args)
    with
	Not_found -> `Fault ("No such function", -1)
	  

let send_response h res =
  let body =
    match res with
      | `Fault (desc, code) ->
	  let buf = Buffer.create 512 in
	  Buffer.add_string buf xml_version;
	  Buffer.add_string buf "\n<methodResponse>\n<fault>\n<value>\n";
	  Buffer.add_string buf "<struct>\n<member><name>faultCode</name><value><int>";
	  Buffer.add_string buf (string_of_int code);
	  Buffer.add_string buf "</int></value></member>\n";
	  Buffer.add_string buf "<member><name>faultString</name><value><string>";
	  Buffer.add_string buf desc;
	  Buffer.add_string buf "</string></value></member>\n</struct>\n</value>\n</fault>\n</methodResponse>";
	  Buffer.contents buf
      | `Value v ->
	  let buf = Buffer.create 512 in
	    Buffer.add_string buf xml_version;
	    Buffer.add_string buf "\n<methodResponse>\n<params>\n<param>\n";
	    Buffer.add_string buf (XmlRPCTypes.print_type v);
	    Buffer.add_string buf "\n</param>\n</params>\n</methodResponse>\n";
	    Buffer.contents buf 
  in
    h.handler#send_reply body

let run h =
  while true do
    try
      let req = h.handler#get_request () in
      let res = handle_request h req in
	send_response h res
    with
      | Error (e,c) -> send_response h (`Fault (e,c))
      | XmlRPCTypes.Bad_type -> send_response h (`Fault ("Invalid type conversion", -1))
      | Validation_error e | WF_error e -> send_response h (`Fault (e, -1))
      | At (where, e) ->
	  match e with
	    | Validation_error e | WF_error e -> send_response h (`Fault (e, -1))
	    | _ -> send_response h (`Fault ("Couldn't handle request", -1))
  done

