(*
    Ocaml XML-RPC support.
    Copyright (C) 2004 Shawn Wagner <raevnos@pennmush.org>

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*)

(* Map XML-RPC types to ocaml types and back *)

open Netencoding
open Pxp_yacc
open Pxp_document
open Format

type xrs = (string, t) Hashtbl.t
and t =
    [
      `Unit
    | `Int of int32
    | `String of string
    | `Boolean of bool
    | `Double of float
    | `Base64 of string
    | `RawBase64 of string
    | `DateTime of string
    | `Array of t array
    | `Struct of xrs
    ]

type fault = {
  desc: string;
  code: int;
}

exception Bad_type

let make_struct () =Hashtbl.create 12

let add_elem = Hashtbl.add
let find_elem = Hashtbl.find

(* Convert ML types to XML-RPC types *)
let xr_of_int i = `Int (Int32.of_int i)
let xr_of_int32 i = `Int i
let xr_of_string s = `String s
let xr_of_bool b = `Boolean b
let xr_of_float f = `Double f
let xr_of_base64 s = `Base64 (Base64.encode s)
let xr_of_rawbase64 s = `RawBase64 s
let xr_of_array ar = `Array ar
let xr_of_struct st = `Struct st

let skip = `Unit

(* Print XML-RPC types as XML *)
let cdata_re = Pcre.regexp ~study:true "[&<>]"

let escape_cdata s =
  Pcre.substitute ~rex:cdata_re ~subst:(function
					  | ">" -> "&gt;"
					  | "<" -> "&lt;"
					  | "&" -> "&amp;"
					  | a -> a) s



let rec print_type = function
  | `Unit -> ""
  | `Int i -> "<value><i4>" ^ (Int32.to_string i) ^ "</i4></value>\n"
  | `String s ->
      "<value><string>" ^ (escape_cdata s) ^ "</string></value>\n"
  | `Boolean b ->
      "<value><boolean>" ^ (if b then "1" else "0") ^ "</boolean></value>\n"
  | `Double f -> 
      "<value><double>" ^ (string_of_float f) ^ "</double></value>\n"
  | `Base64 s | `RawBase64 s -> "<value><base64>" ^ s ^ "</base64></value>\n"
  | `DateTime s ->
      "<value><dateTime.iso8601>" ^ s ^ "</dateTime.iso8601></value>\n"
  | `Array ar ->
      let buf = Buffer.create 512 in
	Array.iter (function x -> Buffer.add_string buf (print_type x)) ar;
      "<value><array><data>\n" ^ (Buffer.contents buf) ^ "</data></array></value>\n"
  | `Struct s ->
      let buf = Buffer.create 512 in
      let print_elem key data =
	Buffer.add_string buf "<member>\n<name>";
	Buffer.add_string buf key;
	Buffer.add_string buf "</name>\n";
	Buffer.add_string buf (print_type data);
	Buffer.add_string buf "</member>\n"
      in
	Hashtbl.iter print_elem s;
	"<value><struct>\n" ^ (Buffer.contents buf) ^ "</struct></value>\n"


(* Convert XML-RPC types to ML types *)
let ml_of_int = function `Int i -> Int32.to_int i | _ -> raise Bad_type
let ml_of_int32 = function `Int i -> i | _ -> raise Bad_type
let ml_of_bool = function `Boolean b -> b | _ -> raise Bad_type
let ml_of_string = function `String s -> s | _ -> raise Bad_type
let ml_of_float = function `Double f -> f | _ -> raise Bad_type
let ml_of_base64 = function `Base64 s | `RawBase64 s -> Base64.decode s
  | _ -> raise Bad_type
let ml_of_rawbase64 = function `Base64 s | `RawBase64 s -> s | _ -> raise Bad_type
let ml_of_array = function `Array ar -> ar | _ -> raise Bad_type
let ml_of_datetime = function `DateTime s -> s | _ -> raise Bad_type
let ml_of_struct = function `Struct st -> st | _ -> raise Bad_type

let ml_of_intarray =
  function `Array ar -> Array.map ml_of_int ar
    | _ -> raise Bad_type

let ml_of_int32array =
  function `Array ar -> Array.map ml_of_int32 ar
    | _ -> raise Bad_type

let ml_of_floatarray = 
  function `Array ar -> Array.map ml_of_float ar
    | _ -> raise Bad_type

let ml_of_stringarray =
  function `Array ar -> Array.map ml_of_string ar
    | _ -> raise Bad_type

let ml_of_boolarray =
  function `Array ar -> Array.map ml_of_bool ar
    | _ -> raise Bad_type

let ml_of_base64array =
  function `Array ar -> Array.map ml_of_base64 ar
    | _ -> raise Bad_type
let ml_of_rawbase64array =
  function `Array ar -> Array.map ml_of_rawbase64 ar
    | _ -> raise Bad_type
let ml_of_datetimearray =
  function `Array ar -> Array.map ml_of_datetime ar
    | _ -> raise Bad_type
let ml_of_structarray =
  function `Array ar -> Array.map ml_of_struct ar
    | _ -> raise Bad_type

let ml_of_fault = 
  function `Struct faults ->
    begin try
      { code = ml_of_int (find_elem faults "faultCode");
	desc = ml_of_string (find_elem faults "faultString");
      }
    with Not_found -> raise Bad_type end
    | _ -> raise Bad_type

(* These assume a well-formed and validated tree. node is a value *)  
let nodename n = match n#node_type with | T_element name -> name

let rec parse_value node =
  if nodename node <> "value" then raise Bad_type;
  let valtype = List.hd node#sub_nodes in
    match nodename valtype with
      | "i4" | "int" -> `Int (Int32.of_string valtype#data)
      | "string" -> `String valtype#data
      | "double" -> `Double (float_of_string valtype#data)
      | "base64" -> `Base64 valtype#data
      | "boolean" -> `Boolean (bool_of_string valtype#data)
      | "dateTime.iso8601" -> `DateTime valtype#data
      | "array" -> `Array (Array.of_list
			 (List.map
			    parse_value (List.hd valtype#sub_nodes)#sub_nodes))
      | "struct" -> let members = valtype#sub_nodes in
	let s = Hashtbl.create (List.length members) in
	  List.iter (function n -> let (key, data) = split_member n in
		   Hashtbl.add s key data) members;
	  `Struct s	   
      | _ -> raise Bad_type
and split_member x =
  match x#sub_nodes with
    | name::value::[] -> (name#data, parse_value value)   
    | _ -> raise Bad_type
