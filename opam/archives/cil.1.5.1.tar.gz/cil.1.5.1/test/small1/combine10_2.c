typedef struct foo PSFOO;
struct foo {
  struct foo * left;
  PSFOO * right;
  int x;
} g2;
