

 
int main(void){
  return 0; 

 this_label_is_not_used: __attribute__ ((unused))
  return 1;
}
