let ocaml_version = "2.99"
let ocaml_name = "ocaml"
let ast_impl_magic_number = "Caml1999M007"
let ast_intf_magic_number = "Caml1999N007"
