let f x = x + 1
external g : string -> int = "caml_int_of_string"
