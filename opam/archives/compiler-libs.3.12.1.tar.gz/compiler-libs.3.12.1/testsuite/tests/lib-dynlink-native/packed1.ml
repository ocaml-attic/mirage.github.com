let () =
  Api.reg_mod "Packed1"

let bla = Sys.argv.(0) ^ "XXX"
let mykey = Sys.argv.(0)

