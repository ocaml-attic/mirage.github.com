#!/bin/sh -e

COMM=ocamlc$OPT
echo $COMM $*
$COMM $*
