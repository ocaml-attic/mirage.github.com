(* Upload script for git repositories *)

let () =
  Globals.error_and_exit "Upload capacity is not available for GIT repositories"
