
  Benchmark - measure/compare run-time of OCaml functions


  Copyright 2004-present, Christophe Troestler

  Copyright 2002-2003, Doug Bagley
  http://www.bagley.org/~doug/ocaml/

----------------------------------------------------------------------

Benchmark provides functions to measure and compare the run-time of
functions.  It is inspired by the Perl module of the same name.

See the file INSTALL for compiling and (un)installing.

Send your comments, bug reports,... to Christophe.Troestler(at)umons.ac.be

----------------------------------------------------------------------

This library is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License version 3
or later as published by the Free Software Foundation, with the
special exception on linking described in file LICENSE.

This library is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the file
LICENSE.txt for more details.
