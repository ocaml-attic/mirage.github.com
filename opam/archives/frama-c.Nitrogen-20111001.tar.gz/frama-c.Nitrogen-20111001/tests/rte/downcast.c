/* run.config
   OPT: -rte -rte-print -journal-disable
   OPT: -rte -rte-no-all -rte-print -rte-signed -journal-disable
*/
int main(void) {
  signed char cx,cy,cz;

  cz = cx + cy;

  return 0;
}
