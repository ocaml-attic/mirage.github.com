//@ logic boolean f(int x) = x == 0 ;

//@ predicate f_pred(int x,int y) = f(x) && f(y) ;

//@ predicate foo(boolean x, boolean y) = x == \false || y ;
