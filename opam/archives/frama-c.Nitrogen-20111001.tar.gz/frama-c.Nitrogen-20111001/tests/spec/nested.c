/*
void f() {
  int i = 0;
  //@ assert i == 0;
}
*/

void g() { }
