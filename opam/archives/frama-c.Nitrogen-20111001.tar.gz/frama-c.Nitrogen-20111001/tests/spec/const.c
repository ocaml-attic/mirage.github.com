//@ logic integer strlen(char* c);

//@ requires strlen(c) < n; ensures strlen(a) <=n;
void f(const char* c, char* restrict a, int n) {

}
