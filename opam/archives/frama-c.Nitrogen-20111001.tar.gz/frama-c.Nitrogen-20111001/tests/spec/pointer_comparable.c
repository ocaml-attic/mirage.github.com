/*@ requires \pointer_comparable((void*)p,(void*)q) && \is_finite(*p) ; */
void f(float*p, char const * q) {
  return;
}
