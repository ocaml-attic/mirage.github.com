typedef struct node {
    int hd;
    struct list * next;
} list;

/*@
  logic set<struct node *> tata(struct node * p) = \empty;
  @*/
