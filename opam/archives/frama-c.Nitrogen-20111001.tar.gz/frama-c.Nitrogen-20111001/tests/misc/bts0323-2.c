/* run.config
   DONTRUN: main test is in bts0323.c
*/
#include "bts0323.h"
int x = 1;
void g() { x =2;}
