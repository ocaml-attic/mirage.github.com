CoHTTP is an OCaml library for creating HTTP daemons.  It uses cooperative
threading via the LWT library to handle concurrency, making it quite
lightweight and portable.

Build Requirements:

* [Lwt](http://ocsigen.org/lwt)
* [Re](http://github.com/avsm/ocaml-re] (not packaged yet, just grab trunk)
* [Uri](http://github.com/avsm/ocaml-uri) (not packaged yet, just grab trunk)
* [oUnit](http://ounit.forge.ocamlcore.org/) unit testing library.
