!!The Channels

* *E-mail*: developer mailing list at [lists.cam.ac.uk](https://lists.cam.ac.uk/mailman/listinfo/cl-mirage) and [archive](https://lists.cam.ac.uk/pipermail/cl-mirage/)
* *IRC*: `#mirage` on `irc.freenode.org`
* *Twitter*: [openmirage](http://twitter.com/openmirage)
* *Meetings*: [Kingston Arms](http://www.kingston-arms.co.uk/)
