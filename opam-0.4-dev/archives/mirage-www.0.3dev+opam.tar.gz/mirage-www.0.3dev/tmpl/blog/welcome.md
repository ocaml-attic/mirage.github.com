Welcome to the new self-hosting website for the Mirage project!  As we go about preparing a release for later in the year, this blog will contain technical musings and work-in-progress reports of various bits of the operating system as they mature. Since there's so much to talk about, we decided to start with a blog format, and eventually collect things into a proper document as they stabilise.

Feel free to subscribe to the [Atom](/blog/atom.xml) feed to keep up-to-date with our progress, or just e-mail us or comment on individual posts with any queries.
