#include <string.h>
int main(void) {
  char arr[16];
  strcpy(arr,"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
  return 0;
}
