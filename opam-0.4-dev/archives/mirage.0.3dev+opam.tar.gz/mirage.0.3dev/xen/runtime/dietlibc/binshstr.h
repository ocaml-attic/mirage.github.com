
extern const char __binsh [8];

#define           __sh   (__binsh + 5 )

/* end of binshstr.h */
