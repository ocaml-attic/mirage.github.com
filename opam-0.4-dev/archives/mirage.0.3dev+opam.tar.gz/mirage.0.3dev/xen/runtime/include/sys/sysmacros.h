#ifndef _SYSMACROS_H
#define _SYSMACROS_H

#include <sys/stat.h>

#endif
