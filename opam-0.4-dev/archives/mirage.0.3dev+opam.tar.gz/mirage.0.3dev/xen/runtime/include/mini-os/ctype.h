#ifndef _CTYPE_H
#define _CTYPE_H

#include_next <ctype.h>

#endif
