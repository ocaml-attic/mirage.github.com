#ifndef _FEATURES_H
#define _FEATURES_H

#ifndef __dietlibc__
#error "not using the diet wrapper?!"
#endif

#endif
