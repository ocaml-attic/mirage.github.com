Requires a bitstring with this packaging fix (r185 upstream):
http://code.google.com/p/bitstring/issues/detail?id=5
