open Foo

INCLUDE "bar"

IFDEF "foo"
let f x = 3
ENDIF

TEST foo
TEST bar
