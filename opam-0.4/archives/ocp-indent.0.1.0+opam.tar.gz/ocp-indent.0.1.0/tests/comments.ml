(* A *)

type x = 
  (* A *)
  | Foo

  (* B *)

  | Bar

(* AA *)

(* D *)
let x = 3


(* ending comments *)

