# ocp-indent

A simple tool to indent OCaml programs

Authors: Thomas Gazagnaire (OCamlPro), Jun Furuse
License: GPL v3.0

## TODO:

- Implement calling the program from Emacs, VI, etc.
- Implement customization per configuration file
- Implement tab-to-space, delete trailing spaces, etc.
