Atdgen uses type definitions in the ATD syntax and generates
efficient [JSON](http://json.org) serializers, deserializers and
validators for OCaml.

Checkout the [tutorial](http://mylifelabs.github.com/atdgen-tutorial.html).
