(* Format quotations tutorial *)
(******************************)

(* Uncomment to execute in the toplevel:
#use "topfind";;
#camlp4o;;
#require "format.syntax";;
*)

(* Or without findlib:
#directory "+camlp4";;
#load "dynlink.cma";;
#load "camlp4o.cma";;
#load "formatLexer.cmo";;
#load "formatParser.cmo";;
#load "pa_format.cmo";;
*)

(* Available quotations *)
(************************)

(* Quotations are available for creating strings, and for writing to
   channels, buffers, and formatters: *)

let _ = <:sprint<Hello world!>>;;
let _ = <:print<Hello world!>>;;
let _ = <:eprint<Hello world!>>;;
let _ = <:fprint<Hello world!>> stdout;;

let _ =
  let b = Buffer.create 16 in
    <:bprint<Hello world!>> b;
    Buffer.contents b
;;

let _ = <:psprint<Hello world!>>;;
let _ = <:pprint<Hello world!>>;;
let _ = <:peprint<Hello world!>>;;
let _ = <:pfprint<Hello world!>> Format.std_formatter;;

let _ =
  let b = Buffer.create 16 in
    <:pbprint<Hello world!>> b;
    Buffer.contents b
;;


(* Simple antiquotations *)
(*************************)

(* Antiquotations allow the insertion of arbitrary data in a string,
   in the same way as formats. For example: *)

let _ = <:print<2+2 = $d:2+2$>>;;
let _ = <:print<pi = $.4f:4.*.atan 1.$>>;;
let _ = let who = "world" in <:print<Hello $s:who$!>>;;

(* All the formats from Printf are supported except those that take
   zero or several arguments (i.e., a, !, %). The syntax is
   identical. The 't' format is supported, but has a different type in
   the case of sprintf: its argument's type is Buffer.t -> unit. *)

let _ = let who = <:bprint<world>> in <:sprint<Hello $t:who$!>>;;
let _ = let who = <:fprint<world>> in <:print<Hello $t:who$!>>;;
let _ = let who = <:fprint<world>> in <:eprint<Hello $t:who$!>>;;
let _ = let who = <:fprint<world>> in <:fprint<Hello $t:who$!>> stdout;;

let _ =
  let who = <:bprint<world>> in
  let b = Buffer.create 16 in
    <:bprint<Hello $t:who$!>> b;
    Buffer.contents b
;;


(* Conditionals and iteration *)
(******************************)

(* The "if then else" construct uses the following syntax:

   $? <cond> ${ <string> }{ <string> }

   (the second string is optional). For example: *)

let _ = <:print<$?Random.bool ()${true}{false}>>;;

(* Iterating over collections is achieved with the syntax

   $! <patt> <- <expr> / <expr>${body}{sep}

   which binds the pattern to each element of the first expression in
   the body. The second expression is the "iter" function for the
   collection type, and defaults to List.iter if omitted. The
   separator is also optional. *)

let _ = <:print<$!i <- [1 ; 2]${$d:i$}>>;;
let _ = <:print<$!i, x <- [1, "one" ; 2, "two"]${$d:i$ = $s:x$; }>>;;
let _ = <:print<[|$!i <- [|1 ; 2|] / Array.iter${$d:i$}{ ; }|]>>;;


(* Escaping and special characters *)
(***********************************)

(* The three characters '$', '{', and '}' must be preceeded by '\'
   when used for themselves: *)
let _ = <:print<\$, \{, \}, ", ">>;;

(* Newline, tabulation, and other special characters can also be
   encoded using Ocaml syntax, and \! flushes the output: *)
let _ = <:print<\tHello\032world!\n\!>>;;

(* Finally, long strings can be broken using backslash: *)
let _ = <:print<A very very very very very very very very very very very very \
                long string>>;;


(* Pretty printing *)
(*******************)

(* Pretty-printing indications work as usual, except for length
   indications which do nothing (the following doesn't work) *)
let _ = <:pfprint<@<2>$d:2$>> Format.std_formatter;;

(* Tags must be specified by @\{ and @\} instead of @{ and @}. *)
let _ = <:pfprint<@\{@\} @\{<tag>@\}>> Format.std_formatter;;


(* Compilation and error reporting *)
(***********************************)

(* Programs should be compiled with:

   ocamlfind ocamlc -syntax camlp4o -package format.syntax

   or (without ocamlfind)

   ocamlc -pp "camlp4o -I path_to_format formatLexer.cmo formatParser.cmo pa_format.cmo"

   Errors should be reported at the correct place. *)
