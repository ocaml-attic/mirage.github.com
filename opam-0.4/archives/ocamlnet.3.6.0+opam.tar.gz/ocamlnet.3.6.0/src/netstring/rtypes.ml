(*
 * $Id: rtypes.ml 1558 2011-03-04 17:15:46Z gerd $
 *
 *)

include Netnumber
include Netnumber.BE
