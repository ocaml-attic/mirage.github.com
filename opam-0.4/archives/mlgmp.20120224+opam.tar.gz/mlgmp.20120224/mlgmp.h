void division_by_zero(void) noreturn;
void raise_unimplemented(const char *s) noreturn;
