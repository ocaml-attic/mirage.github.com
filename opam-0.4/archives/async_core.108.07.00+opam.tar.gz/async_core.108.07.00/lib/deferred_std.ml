open Deferred

include Infix

let choice       = choice
let choose       = choose
let don't_wait_for = don't_wait_for
let never        = never
let return       = return
let upon         = upon
