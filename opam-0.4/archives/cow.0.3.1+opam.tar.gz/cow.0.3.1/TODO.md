Figure out how to make this compile with OASIS.  It doesnt currently
support building a syntax extension and then *using* that to build
the library (which we need for COW).  So the answer is probably two
separate OASIS builds, or extend the tool.
