(*
 * Phony:
 * - for ``user visible'' targets (all, opt, doc, test, install, uninstall) use the Makefile
 * - ``developper visible'' targets: 
 *   + godi_push 
 *       Put godi files in the godi tree.
 *   + web       
 *       Put webpage files on server.
 *   + distrib   
 *       Creates the distributions packages inside _build.
 *   + manual    
 *       Compiles the manual -- notice 'make doc' only compiles the developer doc,
 *       indeed compiling the manual requires LaTeX, this is a useless dependency for 
 *       something that can be compiled in a platform independant way.
 *)
open Ocamlbuild_plugin open Ocamlbuild_pack open StdLabels open Pathname open Command

let web_repository = "aravantv@regstab.forge.ocamlcore.org:/home/groups/regstab/htdocs"

let global_tags = [ "use_str"; "rectypes"; "stars"; ]

let dirs = object (dirs)
  method distro = "distrib"
  method src    = "src"
  method doc    = "doc"
  method ex     = "examples"
  method man    = "man"
  method web    = "webpage"
  method tools  = "tools"
  method godi   = "godi"
  method bin    = "bin"
  method docsrc = dirs#doc/"src"
end

let src_dirs = object
  method common = "common"
  method executables = "executables"
  method procedure = "procedure"
  method schema = "schema"
  method proof = "witness"
end

let pkgbase = getenv ~default:"regstab" "PKGBASE"

let tools = [ "sch2cnf"; "sch2ltl";  ]
let opt_tools = List.map ~f:(fun x -> x ^ ".opt") tools

let installs = [
  "QUICKSTART"                    , "doc"/pkgbase;
  dirs#man/"man1"/"regstab.1"     , "man"/"man1"/"regstab.1";
  dirs#man/"man1"/"regstab.opt.1" , "man"/"man1"/"regstab.opt.1";
  dirs#man/"man1"/"sch2cnf.1"     , "man"/"man1"/"sch2cnf.1";
  dirs#man/"man1"/"sch2cnf.opt.1" , "man"/"man1"/"sch2cnf.opt.1";
  dirs#man/"man1"/"sch2ltl.1"     , "man"/"man1"/"sch2ltl.1";
  dirs#man/"man1"/"sch2ltl.opt.1" , "man"/"man1"/"sch2ltl.opt.1";
  dirs#doc/"manual.pdf"           , "doc"/pkgbase;
  dirs#doc/"developer"            , "doc"/pkgbase/"developer_doc";
  dirs#tools                      , "share"/pkgbase;
  dirs#ex                         , "doc"/pkgbase;
  dirs#bin/"regstab"              , "bin"/"regstab";
  dirs#bin/"regstab.opt"          , "bin"/"regstab.opt";
  ]
  @ List.map (tools @ opt_tools) ~f:(fun x -> dirs#bin/x, "bin"/x)

let included_dirs = 
  [ dirs#distro; dirs#doc; dirs#ex; dirs#man; dirs#src; dirs#tools; dirs#web; dirs#docsrc; ]
  @ List.map ((/) dirs#src) [ src_dirs#common; src_dirs#executables; src_dirs#procedure; src_dirs#schema; src_dirs#proof]

let build_to_tree = [
  dirs#docsrc/"manual.pdf"    , dirs#doc/"manual.pdf";
  dirs#src/src_dirs#executables/"main.byte"        , dirs#bin/"regstab";
  dirs#src/src_dirs#executables/"main.native"      , dirs#bin/"regstab.opt";
  dirs#src/src_dirs#executables/"sch2cnf.byte"     , dirs#bin/"sch2cnf";
  dirs#src/src_dirs#executables/"sch2cnf.native"   , dirs#bin/"sch2cnf.opt";
  dirs#src/src_dirs#executables/"sch2ltl.byte"     , dirs#bin/"sch2ltl";
  dirs#src/src_dirs#executables/"sch2ltl.native"   , dirs#bin/"sch2ltl.opt";
  dirs#doc/"developer.docdir" , dirs#doc/"developer";
]

(* HIERARCHY *)
let build_dir = !Options.build_dir

let (//) target dir =
  match target with
  |`Build when dir = ""    -> pwd/build_dir
  |`Build                  -> pwd/build_dir/dir
  |`Original when dir = "" -> pwd
  |`Original               -> pwd/dir

let originals = List.map ~f:((//) `Original)

(* TAGS*)
let install_tags () =
  tag_any global_tags;
  flag [ "doc"; "ocaml"; "stars" ] (A"-stars");
  flag [ "doc"; "ocaml"; "rectypes"] (A"-rectypes");
  flag [ "doc"; "ocaml"; "sort"] (A"-sort");
  flag [ "doc"; "ocaml"; "hide_warnings"] (A"-hide-warnings")

(* COMMANDS*)
let cp xs dest = Cmd(S((A"cp")::(A"-r")::(List.map (List.rev_append xs [dest]) ~f:(fun x -> P x))))
let mkdir ds = match ds with [] -> Nop | _::_ -> Cmd(S((A"mkdir")::(A"-p")::(List.map ds ~f:(fun d -> P d))))
let mkdir_if_not_exists ds = mkdir (List.filter ds ~f:(fun x -> not(exists x)))
let tar ?(dir=".") dest src = Cmd(S[ A"tar"; A"-czf"; P dest; A"-C"; P dir; P src ])
let touch fs = Cmd(S((A"touch") :: (List.map fs ~f:(fun x -> P x))))
let rm ds = Cmd(S((A"rm")::(A"-rf")::(List.map ds ~f:(fun d -> P d))))

let cp_builds_to_tree () =
  Seq (List.map build_to_tree ~f:(fun (src,dest) -> if exists (`Build//src) then cp [`Build//src] (`Original//dest) else Nop))

let rec readdirs files =
  List.fold_left files ~init:[] ~f:(fun acc f ->
    if (Filename.basename f).[0] = '_' then acc 
    else 
      (if is_directory f
      then acc @ (readdirs (List.map (Array.to_list & readdir & f) ~f:((/) f)))
      else f::acc))

(* RULES*)
let fake_prod_rule name ?(tags=[]) ?(prods=[]) ?(deps=[]) ?prod ?dep ?stamp ?(insert = `bottom) code =
  let cmd prods env builder = Seq[ code env builder; touch (List.map prods ~f:env); ] in
  match prod,dep,stamp with
  |None,None,None                -> rule name ~tags ~prods ~deps ~insert             (cmd prods)
  |None,None,Some stamp          -> rule name ~tags ~prods ~deps ~insert ~stamp      (cmd prods)
  |None,Some dep,None            -> rule name ~tags ~prods ~deps ~insert ~dep        (cmd prods)
  |None,Some dep,Some stamp      -> rule name ~tags ~prods ~deps ~insert ~dep ~stamp (cmd prods)
  |Some prod,None,None           -> rule name ~tags ~prods ~deps ~insert ~prod             (cmd (prod::prods))
  |Some prod,None,Some stamp     -> rule name ~tags ~prods ~deps ~insert ~prod ~stamp      (cmd (prod::prods))
  |Some prod,Some dep,None       -> rule name ~tags ~prods ~deps ~insert ~prod ~dep        (cmd (prod::prods))
  |Some prod,Some dep,Some stamp -> rule name ~tags ~prods ~deps ~insert ~prod ~dep ~stamp (cmd (prod::prods))
let dir_dep_rule ?(flags=false) ?dep ?(deps=[]) =
  let flag x = if flags then add_extension "flag" x else x in
  rule ~deps:(List.map (readdirs (match dep with None -> deps | Some dep -> dep::deps)) ~f:flag)

let install_rules () =
  rule "Clean" ~prod:"clean" (fun _ _ -> rm (List.map ~f:((//) `Original) & snd & List.split & build_to_tree));
  fake_prod_rule "Bytecode" ~prod:"byte" ~deps:(
    (dirs#src/src_dirs#executables/"main.byte") :: List.map tools ~f:(fun t -> dirs#src/src_dirs#executables/t^".byte")
  ) (fun _ _ -> cp_builds_to_tree ());
  fake_prod_rule "Native" ~prod:"opt" ~deps:(
    (dirs#src/src_dirs#executables/"main.native") :: List.map tools ~f:(fun t -> dirs#src/src_dirs#executables/t^".native")
  ) (fun _ _ -> cp_builds_to_tree ());
  fake_prod_rule "Developer manual" ~prod:"developer_doc" ~dep:(dirs#doc/"developer.docdir"/"index.html") (fun _ _ -> cp_builds_to_tree ());

  rule "Test" ~prod:"test_run" (fun _ _ -> Seq[Cmd(S[A"cd"; P(`Original//dirs#ex); Sh";"; A(`Original//dirs#ex/"run");])]);

  fake_prod_rule "Manual" ~prod:"manual" ~dep:(dirs#docsrc/"manual.pdf") (fun _ _ -> cp_builds_to_tree ());
  rule "Manual.pdf" ~prod:(dirs#docsrc/"manual.pdf") ~deps:[dirs#docsrc/"manual.tex"; dirs#docsrc/"aravantinos.bib"; dirs#docsrc/"RegSTABlogo.png"; ] 
  (fun _ _ -> 
    let cd_first = S[A"cd"; P dirs#docsrc; Sh";"] in
    let pdflatex = Cmd(S[cd_first; S[ A"pdflatex" ; P"manual.tex"]]) in
    let bibtex   = Cmd(S[cd_first; S[ A"bibtex" ; P"manual"]]) in
    Seq[ pdflatex; bibtex; pdflatex; pdflatex;]);

  let version =
    let ch = open_in "VERSION" in
    let line = input_line ch in
    close_in ch; line 
  in
  let src_archive_files =
    [ "INSTALL"; "Makefile"; "COPYRIGHT"; "LICENSE"; "CHANGES"; "QUICKSTART"; "VERSION"; "myocamlbuild.ml";
    dirs#bin; dirs#doc; dirs#ex; dirs#man; dirs#src; dirs#tools; ] in
  let new_dir = "regstab-" ^ version in
  let archive x = new_dir ^ x ^ ".tar.gz" in
  let clean = Seq[Cmd(S[A"rm"; A"-f"; Sh(`Original//dirs#bin/"*")])] in

  dir_dep_rule "Webpage" ~flags:true ~prod:"web" ~dep:dirs#web (fun _ _ -> Nop);
  fake_prod_rule "Webfile" ~prod:(dirs#web/"%.flag") ~dep:(dirs#web/"%") (fun env _ ->
    Seq[Cmd(S[A"scp"; A"-r"; P(`Original//dirs#web/(env "%")); P web_repository])]);

  dir_dep_rule "Godi" ~flags:true ~prod:"godi_push" ~deps:[(archive ""); dirs#godi] (fun _ _ -> Nop);
  fake_prod_rule "Godi file" ~prod:(dirs#godi/"%.flag") ~dep:(dirs#godi/"%") (fun env _ ->
    Cmd(S[A"sudo"; A"cp"; A"-f"; P(`Original//dirs#godi/(env "%")); P"/opt/godi/build/apps/apps-regstab/"]));
  fake_prod_rule "Godi archive" ~prod:((archive "")^".flag") ~dep:(archive "") (fun _ _ ->
    Cmd(S[A"sudo"; A"cp"; A"-f"; P(`Build//(archive "")); P"/opt/godi/build/distfiles/"]));

  dir_dep_rule "Distrib Source" ~prod:(archive "") ~deps:("manual"::src_archive_files) (fun _ _ -> Seq[
    clean;
    mkdir [new_dir];
    cp (originals src_archive_files) new_dir;
    tar (archive "") new_dir;
    rm [new_dir]; 
  ]);

  dir_dep_rule "Distrib OSX" ~prod:(archive "-IntelOSX") 
  ~deps:["byte";"opt";"manual";"COPYRIGHT";"LICENSE"; "CHANGES";"QUICKSTART";"VERSION";dirs#ex;dirs#man;dirs#tools;]
  (fun _ _ -> Seq[
    mkdir [new_dir; new_dir/dirs#doc; ];
    cp (originals [dirs#bin; dirs#man; dirs#tools; dirs#ex;]) new_dir;
    cp (originals ["QUICKSTART"; "CHANGES"; "VERSION"; "COPYRIGHT"; "LICENSE"; ]) new_dir;
    cp [`Original//dirs#doc/"manual.pdf"] (new_dir/dirs#doc);
    tar (archive "-IntelOSX") new_dir;
    rm [new_dir]; 
  ]);

  dir_dep_rule "Distrib Win32" ~prod:(archive "-Win32") 
  ~deps:["byte";"opt";"COPYRIGHT";"LICENSE";"CHANGES";"QUICKSTART";"VERSION";dirs#ex;dirs#man;dirs#tools;]
  (fun _ _ -> Seq[
    mkdir [new_dir; new_dir/dirs#doc; ];
    cp (originals [dirs#bin; dirs#man; dirs#tools; dirs#ex;]) new_dir;
    cp (originals ["QUICKSTART"; "CHANGES"; "VERSION"; "COPYRIGHT"; "LICENSE"; ]) new_dir;
    cp [`Original//dirs#doc/"manual.pdf"] (new_dir/dirs#doc);
    tar (archive "-Win32") new_dir;
    rm [new_dir]; 
  ]);

  dir_dep_rule "Distrib Bytecode" ~prod:(archive "-bytecode") 
  ~deps:["byte";"manual";"COPYRIGHT";"LICENSE";"CHANGES";"QUICKSTART";"VERSION";dirs#ex;dirs#man;dirs#tools;] 
  (fun _ _ -> Seq[
    mkdir [new_dir; new_dir/dirs#bin; new_dir/dirs#doc; new_dir/dirs#man; ];
    cp (originals ((dirs#bin/"regstab") :: List.map tools ~f:(fun x -> dirs#bin/x))) (new_dir/dirs#bin);
    cp (originals [dirs#man/"man1"/"regstab.1"; dirs#man/"man1"/"sch2cnf.1"]) (new_dir/dirs#man);
    cp (originals [dirs#tools; dirs#ex;]) new_dir;
    cp (originals ["QUICKSTART"; "CHANGES"; "VERSION"; "COPYRIGHT"; "LICENSE"; ]) new_dir;
    cp [`Original//dirs#doc/"manual.pdf"] (new_dir/dirs#doc);
    tar (archive "-bytecode") new_dir;
    rm [new_dir]; 
  ]);

  rule "Distrib" ~prod:"distrib" ~deps:(List.map ["";"-IntelOSX";"-bytecode"] ~f:archive) (fun _ _ -> Nop);

  let prefix  =
    let absolute x = if is_relative x then `Original//x else x in
    absolute (getenv ~default:"/usr/local" "PREFIX")
  in
  let installs = List.map installs ~f:(fun (x,y) -> `Original//x, prefix/y) in
  rule "Install" ~prod:"install" ~dep:"byte" (fun _ _ ->
    Seq((mkdir_if_not_exists (List.map ~f:dirname & snd & List.split installs)) :: (List.map installs ~f:(fun (x,y) -> if exists x then cp [x] y else Nop)))
  );
  rule "Uninstall" ~prod:"uninstall" (fun _ _ -> rm & snd & List.split & installs)

(* MAIN *)
  
let _ = dispatch & function
  |After_rules -> begin
    Options.include_dirs := included_dirs;
    install_tags ();
    install_rules ();
  end
  |_ -> ()
