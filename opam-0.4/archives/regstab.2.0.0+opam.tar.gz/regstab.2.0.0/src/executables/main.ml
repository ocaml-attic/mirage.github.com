(** Command-line function. *)
open Softcore open Lexing open Schema open Model

(**/**)
(* The main function, called with the input channel *)
let main ~verbose ~lexbuf ~regstab ch =
  print_endline (try
      let expected,(sch,cstr,param,bound_var) = Parser.main Lexer.token lexbuf in
      regstab ~expectation:expected ~param ~var:bound_var ~cstr sch
    with Failure s -> s);
  flush stdout

let gc_tuning () = Gc.set { (Gc.get ()) with Gc.minor_heap_size = 3000000 }
(**/**)

(* Handling of command-line options, calls main *)
let _ =
  let channel = ref None in
  let verbose = ref 0 in
  let print_lemmas = ref false in
  let print_model = ref false in
  let print_all_lemmas = ref false in
  let print_proof = ref None in
  let parse_print_proof x = print_proof := Some x in
  let tune_gc = ref true in
  let stats = ref false in
  let excluded_vars = ref [] in
  let use_inclusion = ref false in
  let utf8 = ref true in
  let machine_proof = ref false in
  let parse_excluded_vars vs = excluded_vars := List.map ~f:Proposition.of_human (String.ASCII.split ~on:',' vs) in
  let human_xml = ref false in
  let options = Arg.align [
    "--exclude-vars", Arg.String(parse_excluded_vars), " If the schema is satisfiable, exclude the given variables of the printed model";
    "-l", Arg.Set(print_lemmas), " Print the lemmas used in the deduction";
    "--lemmas", Arg.Set(print_all_lemmas), " Print the lemmas database (all lemmas, not just those used in the deduction)";
    "-m", Arg.Set(print_model), " Print a model when the schema is satisfiable";
    "--model", Arg.Set(print_model), " Same as -m";
    "--not-tune-gc", Arg.Clear(tune_gc), " Turn off garbage collector tuning";
    "-p", Arg.String(parse_print_proof), " Output the proof in the given file when the schema is unsatisfiable";
    "--machine-proof", Arg.Set(machine_proof), " When the proof is generated, generate it in a \"machine\"-oriented way, see documentation";
    "--no-utf8", Arg.Clear(utf8), " Display text in ASCII rather than UTF8";
    "--human-xml", Arg.Set(human_xml), " Output XML in such a way that it is (a bit) more readable by humans";
    "--proof", Arg.String(parse_print_proof), " Same as -p";
    "--used-lemmas", Arg.Set(print_lemmas), " Same as -l";
    "--stats", Arg.Set(stats), " Provide statistics once the execution is over (number of rules applied, number of lemmas, ...)";
    "-s", Arg.Set(stats), " Same as --stats";
    "--use-inclusion", Arg.Set(use_inclusion), " Use inclusion instead of equality to detect cycles (generally slower but gives more concise proofs)";
    "--verbose", Arg.Set_int(verbose), " Verbose level (1 to 3)";
    "-v", Arg.Set_int(verbose), " Same as --verbose";
    "-x", Arg.String(parse_excluded_vars), " Same as --exclude-vars";
  ] in
  let usage = "regstab [file] - says if the schema in file is satisfiable, schema taken on stdin if no file provided" in
  let file s = 
    match !channel with
    |None   -> channel := Some s
    |Some _ -> failwith "Too many arguments."
  in
  Arg.parse options file usage;
  if !tune_gc then gc_tuning ();
  let model = if not !print_model then None else Some !excluded_vars in
  let regstab = DispatchOptions.regstab
      ~display_kind:(if !utf8 then `UTF8 else `ASCII)
      ~human_xml:!human_xml
      ~model 
      ~proof:!print_proof
      ~machine_proof:!machine_proof
      ~stats:!stats
      ~verbose:!verbose
      ~used_lemmas:!print_lemmas
      ~all_lemmas:!print_all_lemmas
      ~use_inclusion:!use_inclusion
  in
  match !channel with
  |None -> 
      print_endline "Taking input from stdin.";
      main stdin ~verbose:!verbose ~lexbuf:(from_channel stdin) ~regstab
  |Some file -> 
      read_wrap ~f:(
        fun ch ->
        let lexbuf = from_channel ch in
        main ch ~verbose:!verbose ~lexbuf:{ lexbuf with lex_curr_p = { lexbuf.lex_curr_p with pos_fname = file } } ~regstab) file

