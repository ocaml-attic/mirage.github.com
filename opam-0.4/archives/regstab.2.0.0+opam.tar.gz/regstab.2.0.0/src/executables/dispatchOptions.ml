(**
 * This module returns the appropriate function [regstab] according to the user options.
 * This function takes the user options and applies the corresponding functors in order to get the expected behaviour.
 * It is pretty big because most functor applications are done on a per-case basis:
 * a given option for a particular module requires that its dependencies also apply the option.
 * Since many options extend the signature (e.g. the proof options add functions to retrieve the proof),
 * this cannot be factorized using first-class modules.
 *
 * Note: we could just make the module with all options activated, this would still work when those options are not needed.
 * But we would lose *a lot* of efficiency then (e.g. generating a proof is much slower than just returning SAT/UNSAT).
 *)
open Softcore

(** All parameters are user-level options except the constraint [cstr] and the schema (which are of course always needed).
 * [param] and [var] cannot be really considered as user-level options either, but they are not essential to the procedure.
 * The returned string contains both the result and the additional information reflecting the user options.
 *)
let regstab ~use_inclusion ~human_xml ~model ~proof ~stats ~used_lemmas ~verbose ~expectation 
  ~all_lemmas ~machine_proof ~display_kind ~param ~var ~cstr sch =

  (* Basically, for every module of the dependency chain, we apply the corresponding functors in order to satisfy the requested options. *)
  let module K = 
    (val (match display_kind with
    |`UTF8 -> (module String.UTF8 : String.S)
    |`ASCII -> (module String.ASCII : String.S)
    ) : String.S)
  in
  let module Output_info =
    struct
      module S = K
      let parameter = param
      let bound_variable = var
      let bounds = Schema.bounds_of sch
    end
  in
  let module Dispatch =
    struct
      module AB =
        struct
          module Std = AtomicSchemaSet.Std
          module M  = AtomicSchemaSet.Extend_with_model(Std)
        end

      module B =
        struct
          module Std = SchemaSet.Make(AB.Std)
          module M   = SchemaSet.Make(AB.M)
        end

      module RA =
        struct
          module Mk' = RuleApplication.Make_std
          module type Mk_S = functor (B : SchemaSet.S) -> RuleApplication.S with module SchemaSet = B
          module Mk = (val (
              if verbose >= 3
              then (module functor (B : SchemaSet.S) -> RuleApplication.Extend_with_verbose(Mk'(B))(Output_info) : Mk_S)
              else (module Mk' : Mk_S)
            ) : Mk_S) 
          module ExP = RuleApplication.Extend_with_proof
          module ExS = RuleApplication.Extend_with_stats
          module ExPS = RuleApplication.Extend_with_proof_and_stats

          module Std = Mk(B.Std)
          module M   = Mk(B.M)
          module P   = ExP(Std)
          module MP  = ExP(M)
          module S   = ExS(Std)
          module MS  = ExS(M)
          module PS  = ExPS(Std)
          module MPS = ExPS(M)
        end

      module N =
        struct
          module Mk = Node.Make_std
          module ExP = Node.Extend_with_proof
          module ExU = Node.Extend_with_used_info
          module ExS = ExU (* used info is needed for stats later on *)
          module ExSU = ExS
          module ExPU = Node.Extend_with_proof_and_used_info (* proof already includes used info *)
          module ExPS = ExPU
          module ExPSU = ExPU

          module Std  = Mk(RA.Std)
          module M    = Mk(RA.M)
          module S    = ExS(Mk(RA.S))
          module MS   = ExS(Mk(RA.MS))
          module P    = ExP(Mk(RA.P))(RA.P)
          module MP   = ExP(Mk(RA.MP))(RA.MP)
          module PS   = ExPS(Mk(RA.PS))(RA.PS)
          module MPS  = ExPS(Mk(RA.MPS))(RA.MPS)

          module U    = ExU(Std)
          module MU   = ExU(M)
          module SU   = ExSU(S)
          module MSU  = ExSU(MS)
          module PU   = ExPU(P)(RA.P)
          module MPU  = ExPU(MP)(RA.MP)
          module PSU  = ExPSU(PS)(RA.PS)
          module MPSU = ExPSU(MPS)(RA.MPS)
        end

      module L =
        struct
          module type Mk_S = module type of Lemmas.Make_std_equal
          module Mk' = (val (
              if use_inclusion
              then (module Lemmas.Make_std_include : Mk_S)
              else (module Lemmas.Make_std_equal   : Mk_S)
            ) : Mk_S) 
          module Mk = (val (
              if verbose >= 2
              then (module functor (N : Node.S) -> Lemmas.Extend_with_verbose(Mk'(N))(Output_info) : Mk_S)
              else (module Mk' : Mk_S)
            ) : Mk_S) 

          module ExU = Lemmas.Extend_with_used_lemmas
          module ExS = Lemmas.Extend_with_stats
          module ExSU = Lemmas.Extend_with_stats_and_used_lemmas

          module Std  = Mk(N.S) 
          module M    = Mk(N.M) 
          module S    = ExS(Mk(N.S))(N.S)
          module MS   = ExS(Mk(N.MS))(N.MS)
          module P    = Mk(N.P) 
          module MP   = Mk(N.MP) 
          module PS   = ExS(Mk(N.PS))(N.PS)
          module MPS  = ExS(Mk(N.MPS))(N.MPS)
          module U    = ExU(Mk(N.U))(N.U)
          module MU   = ExU(Mk(N.MU))(N.MU)
          module SU   = ExSU(Mk(N.SU))(N.SU)
          module MSU  = ExSU(Mk(N.MSU))(N.MSU)
          module PU   = ExU(Mk(N.PU))(N.PU)
          module MPU  = ExU(Mk(N.MPU))(N.MPU)
          module PSU  = ExSU(Mk(N.PSU))(N.PSU)
          module MPSU = ExSU(Mk(N.MPSU))(N.MPSU)
        end

      module EN =
        struct
          module Std  = ExpandNode.Make_std(L.Std)
          module M    = ExpandNode.Make_std(L.M)
          module S    = ExpandNode.Make_std(L.S)
          module MS   = ExpandNode.Make_std(L.MS)
          module P    = ExpandNode.Make_std(L.P)
          module MP   = ExpandNode.Make_std(L.MP)
          module PS   = ExpandNode.Make_std(L.PS)
          module MPS  = ExpandNode.Make_std(L.MPS)
          module U    = ExpandNode.Make_std(L.U)
          module MU   = ExpandNode.Make_std(L.MU)
          module SU   = ExpandNode.Make_std(L.SU)
          module MSU  = ExpandNode.Make_std(L.MSU)
          module PU   = ExpandNode.Make_std(L.PU)
          module MPU  = ExpandNode.Make_std(L.MPU)
          module PSU  = ExpandNode.Make_std(L.PSU)
          module MPSU = ExpandNode.Make_std(L.MPSU)
        end

      module R =
        struct
          include Regstab

          module type Mk_S = functor (E : ExpandNode.S) -> S with module ExpandNode = E

          module Mk_with_expectation_or_not = (val (
            match expectation with
            |Some e -> (module functor (E : ExpandNode.S) -> Extend_with_expectation(Make_std(Output_info)(E))(struct let expected = e end) : Mk_S)
            |None -> (module Make_std(Output_info) : Mk_S))
            : Mk_S)

          module Mk_with_verbosity = (val (
              if verbose >= 1
              then (module functor (E : ExpandNode.S) -> Extend_with_verbose(Mk_with_expectation_or_not(E))(K) 
                : Mk_S)
              else (module Mk_with_expectation_or_not : Mk_S)
            ) : Mk_S) 

          module Mk = (val (
            if all_lemmas
            then (module functor (E : ExpandNode.S) -> Extend_with_all_lemmas_printing(Mk_with_verbosity(E)) : Mk_S)
            else (module Mk_with_verbosity : Mk_S)) : Mk_S)

          module ExS = Extend_with_stats
          module ExM = Extend_with_model
          module ExP = Extend_with_proof
          module ExU = Extend_with_used_lemmas

          module Std                  = Mk(EN.Std)
          module S                    = ExS(Mk(EN.S))(RA.S)(L.S)
          module M                    = ExM(Mk(EN.M))(AB.M)
          module P                    = ExP(Mk(EN.P))(N.P)
          module MS                   = ExM(ExS(Mk(EN.MS))(RA.MS)(L.MS))(AB.M)
          module MP(P:PROOF_PARAMS)   = ExM(ExP(Mk(EN.MP))(N.MP)(P))(AB.M)
          module PS                   = ExP(ExS(Mk(EN.PS))(RA.PS)(L.PS))(N.PS)
          module MPS(P:PROOF_PARAMS)  = ExM(ExP(ExS(Mk(EN.MPS))(RA.MPS)(L.MPS))(N.MPS)(P))(AB.M)
          module U                    = ExU(Mk(EN.U))(L.U)
          module SU                   = ExU(ExS(Mk(EN.SU))(RA.S)(L.SU))(L.SU)
          module MU                   = ExM(ExU(Mk(EN.MU))(L.MU))(AB.M)
          module PU(P:PROOF_PARAMS)   = ExU(ExP(Mk(EN.PU))(N.PU)(P))(L.PU)
          module MSU                  = ExM(ExU(ExS(Mk(EN.MSU))(RA.MS)(L.MSU))(L.MSU))(AB.M)
          module MPU(P:PROOF_PARAMS)  = ExM(ExU(ExP(Mk(EN.MPU))(N.MPU)(P))(L.MPU))(AB.M)
          module PSU(P:PROOF_PARAMS)  = ExU(ExP(ExS(Mk(EN.PSU))(RA.PS)(L.PSU))(N.PSU)(P))(L.PSU)
          module MPSU(P:PROOF_PARAMS) = ExM(ExU(ExP(ExS(Mk(EN.MPSU))(RA.MPS)(L.MPSU))(N.MPSU)(P))(L.MPSU))(AB.M)
        end
      open R

      module Contents = (val (
        match proof with
        |None -> begin
          match model with
          |None -> begin
            match stats,used_lemmas with
            |false,false -> (module Std : S)
            |false,true  -> (module U   : S)
            |true,false  -> (module S   : S)
            |true,true   -> (module SU  : S)
          end
          |Some x -> begin
            let module X = struct let excluded_variables = x end in
            match stats,used_lemmas with
            |false,false -> (module M(X)   : S)
            |false,true  -> (module MU(X)  : S)
            |true,false  -> (module MS(X)  : S)
            |true,true   -> (module MSU(X) : S)
          end
        end
        |Some file -> begin
          let module F = struct let file = file let machine_oriented = machine_proof let human_xml = human_xml end in
          match model with
          |None -> begin
            match stats,used_lemmas with
            |false,false -> (module P(F)   : S)
            |false,true  -> (module PU(F)  : S)
            |true,false  -> (module PS(F)  : S)
            |true,true   -> (module PSU(F) : S)
          end
          |Some x -> begin
            let module X = struct let excluded_variables = x end in
            match stats,used_lemmas with
            |false,false -> (module MP(F)(X)   : S)
            |false,true  -> (module MPU(F)(X)  : S)
            |true,false  -> (module MPS(F)(X)  : S)
            |true,true   -> (module MPSU(F)(X) : S)
          end
        end) : S)

      include Contents
    end
    in
    Dispatch.O.S.to_string (fst (Dispatch.regstab ~cstr sch))
