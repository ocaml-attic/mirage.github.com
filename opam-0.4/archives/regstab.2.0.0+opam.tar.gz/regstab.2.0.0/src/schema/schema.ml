(** Datatypes and operations related to schemas.
 * A schema (implicitly, a regular schema) is a flat skeleton paired with bounds
 *)
open Softcore

(** Signature of the module *)
module type S =
  sig
    (** Type of schemas. *)
    type t

    (** {6 Constructors} *)

    val of_propositional_skeleton : Prop.t -> t

    (** {6 Destructors} *)

    val skeleton_of : t -> Flat.t

    (** The result is an option because if the schema contains no iteration then there is no need for any bound. *)
    val bounds_of : t -> Bounds.t option
    val has_iterations : t -> [ `No | `Yes of Bounds.t ]

    (** {6 Useful functions} *)

    (** Computes the negation of a skeleton. *)
    val opposite : t -> t

    (** Computes the propositional formula corresponing to a given value of the parameter. *)
    val compute : t -> n:int -> Prop.t

    (** Boolean algebra related simplifications. *)
    val algebraic_simplification : cstr:Constraint.t -> t -> t

    (** {6 Conversions from/to human schemas} *)

    val to_human : param:string option -> var:string option -> t -> Human.schema
    val of_human : Human.schema -> t

    (** {6 Output to XML} *)
    (** Note: the output depends on the wanted encoding for strings, hence the functor. *)
    module Output : functor (S : String.S) -> sig val to_xml : t -> XML(S).t end
  end

(**/**)
module Exposed =
  struct
    type t = With_iteration of Bounds.t * Flat.t | Without_iteration of Prop.t

    let of_propositional_skeleton sk = Without_iteration sk

    let has_iterations = function Without_iteration _ -> `No | With_iteration(b,_) -> `Yes b
    let skeleton_of = function With_iteration(_,sk) -> sk | Without_iteration sk -> Flat.of_prop sk
    let bounds_of = function With_iteration(b,_) -> Some b | Without_iteration _ -> None

    let equal s1 s2 =
      match s1,s2 with
      |With_iteration _,Without_iteration _ |Without_iteration _,With_iteration _ -> false
      |With_iteration(b1,sk1),With_iteration(b2,sk2) -> Bounds.equal b1 b2 && Flat.equal sk1 sk2
      |Without_iteration sk1, Without_iteration sk2 -> Prop.equal sk1 sk2

    let total_compare s1 s2 =
      match s1,s2 with
      |Without_iteration _, With_iteration _ -> -1
      |With_iteration _, Without_iteration _ -> 1
      |With_iteration(b1,s1), With_iteration(b2,s2) ->
        let bnd_cmp = Bounds.total_compare b1 b2 in
        if bnd_cmp <> 0 then bnd_cmp else Flat.total_compare s1 s2
      |Without_iteration sk1, Without_iteration sk2 -> Prop.total_compare sk1 sk2

    let to_human ~param ~var = function
      |With_iteration(bounds,sk) -> Flat.to_human ~param ~var ~bounds:(Some bounds) sk
      |Without_iteration sk -> Prop.to_human ~var:param sk

    let of_human x = 
      match Human.bounds_of x with
      |Some(l,u) -> With_iteration(Bounds.of_human l u, Flat.of_human x)
      |None -> Without_iteration(Prop.of_human x)

    let opposite = function
      |With_iteration(b,sk) -> With_iteration(b,Flat.opposite sk)
      |Without_iteration sk -> Without_iteration(Prop.opposite sk)

    let algebraic_simplification ~cstr = function
      |With_iteration(bounds,sk) -> With_iteration(bounds,Flat.algebraic_simplification ~bounds ~cstr sk)
      |Without_iteration sk -> Without_iteration(Prop.algebraic_simplification sk)

    let compute = function
      |With_iteration(bounds,sk) -> Flat.compute ~bounds sk
      |Without_iteration sk -> Prop.compute sk

    module Output (S : String.S) =
      struct
        module X = XML(S)
        module F = Flat.Output(S)
        module B = Bounds.Output(S)

        let (!~) = S.of_string
        let to_xml x =
          let bounds,sk =
            match x with
            |With_iteration(bounds,sk) -> Some bounds, sk
            |Without_iteration sk -> None, Flat.of_prop sk
          in
          let attrs = [ !~"parameter", !~"n"; !~"bound_var", !~"i"; ] @ (Option.map_value bounds ~default:[] ~f:B.to_xml) in
          X.node ~tag:(S.of_string "regular_schema") ~attrs [ F.to_xml sk ]
      end
  end

include (Exposed : S)
