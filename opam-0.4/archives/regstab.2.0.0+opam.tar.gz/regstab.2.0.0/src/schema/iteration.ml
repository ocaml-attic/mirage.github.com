(** Datatype and operations related to iterations. *)
open Softcore

(** Signature of the module *)
module type S =
  sig
    (** Type of iterations *)
    type t

    (** {6 Comparisons} *)

    val equal : t -> t -> bool
    val total_compare : t -> t -> int

    (** {6 Destructors} *)

    val is_disjunction : t -> bool
    val body_of : t -> Prop.t

    (** {6 Useful operations} *)

    (** Computes the opposite of a literal. *)
    val opposite : t -> t

    (** Unfolds an iteration: returns a triple containing the connective of the iteration, the unfolded schema, and the remaining iteration.
     * Note that, in the current implementation, bounds are not stored in the iteration (but at the schema level);
     * hence the iteration which is returned is just the same as the one which is input.
     *)
    val unfold : t -> Connective.Big.t * Prop.t * t

    (** Performs simplifications depending on the constraint and the bounds:
      * if the constraint and bounds make the iteration empty, then return [`Bot] or [`Top] depending on the connective.
      * Also performs possible boolean simplifications.
      *)
    val algebraic_simplification : cstr:Constraint.t -> bounds:Bounds.t -> t -> [ `Top | `Bot | `It of t ]

    (** Computes the propositional formula corresponing to a given value of the parameter *)
    val compute : bounds:Bounds.t -> n:int -> t -> Prop.t

    (** {6 Conversions from/to human iterations} *)

    (** @raise Only_bound_variable_shall_be_used_in_body if two distinct variables are use in the iteration. *)
    val of_human : Human.iteration -> t
    exception Only_bound_variable_shall_be_used_in_body of string * string
    val to_human : param:string -> var:string -> bounds:Bounds.t -> t -> Human.iteration

    (** {6 Output to XML} *)
    (** Note: the output depends on the wanted encoding for strings, hence the functor. *)
    module Output : functor (S : String.S) -> sig val to_xml : t -> XML(S).t end

    (** {6 Set of iterations} *)

    module Set : MoreLabels.Set.S with type elt = t
  end

(**/**)
module Exposed =
  struct
    type t = int

    type data = {
      op : Connective.Big.t;
      body : Prop.t;
      opposite : int;
      unfold : Connective.Big.t * Prop.t * t;
    }

    let it_to_int = Hashtbl.create 9973
    let int_to_it : (int,data) Hashtbl.t = Hashtbl.create 9973
    let nb_its = ref 0

    let opposite (op,sk) = Connective.Big.opposite op, Prop.opposite sk
    let unfold (op,sk) it ~bounds = (op, Prop.substitute_variable ~by:(Indexes.add (Bounds.upper_of bounds) 1) sk, it)

    let create ((op,sk) as it) ~bounds =
      match Hashtbl.find it_to_int it with
      |Some v -> v
      |None ->
          let it_tag = !nb_its in
          let opposite_it_tag = it_tag + 1 in
          let ((opposite_op,opposite_sk) as opposite_it) = opposite (op,sk) in
          let data     = { op = op;     body = sk;     opposite = opposite_it_tag; unfold = unfold (op,sk) it_tag ~bounds;    } in
          let opposite_data = { op = opposite_op; body = opposite_sk; opposite = it_tag;     unfold = unfold opposite_it opposite_it_tag ~bounds; } in
          (nb_its := !nb_its + 2;
          Hashtbl.add it_to_int ~key:it ~data:it_tag;
          Hashtbl.add int_to_it ~key:it_tag ~data:data; 
          Hashtbl.add it_to_int ~key:opposite_it ~data:opposite_it_tag;
          Hashtbl.add int_to_it ~key:opposite_it_tag ~data:opposite_data; 
          it_tag)

    let find = Hashtbl.find_exn int_to_it

    let equal (x:int) (y:int) = (x = y)
    let body_of it = (find it).body
    let is_disjunction it_tag = Connective.Big.is_disjunction (find it_tag).op 

    let unfold it_tag = (find it_tag).unfold

    let to_human ~param ~var ~bounds it =
      let it = find it in
      let lower,upper = Bounds.to_human ~var:param bounds in
      Connective.Big.to_human it.op, var, lower, upper, Prop.to_human ~var:(Some var) it.body

    exception Only_bound_variable_shall_be_used_in_body of string * string
    let of_human (op,v,l,u,b) =
      try
        match Human.free_variable_of b with
        |Some v' when v' <> v -> raise (Only_bound_variable_shall_be_used_in_body(v,v'))
        |Some _ | None -> create (Connective.Big.of_human op, Prop.of_human b) ~bounds:(Bounds.of_human l u)
      with Human.More_than_one_free_variable(v1,v2) ->
        raise(Only_bound_variable_shall_be_used_in_body(v, if v1 <> v then v1 else v2))

    let total_compare (x:int) (y:int) = Pervasives.compare x y

    let opposite it_tag = (find it_tag).opposite

    let algebraic_simplification ~cstr:hyp ~bounds it_tag =
      let it = find it_tag in
      let upper = Bounds.upper_of bounds in
      let lower = Indexes.of_int (Bounds.lower_of bounds) in
      match it.body with
      |s   when Constraint.always_greater_than ~hyp lower upper -> (Connective.Big.neutral it.op :> [ `Top | `Bot | `It of t ])
      |s -> `It(create ~bounds (it.op,Prop.algebraic_simplification s))

    let compute ~bounds ~n it_tag =
      let it = find it_tag in
      let lower = Bounds.lower_of bounds in
      let upper = Bounds.upper_of bounds in
      Prop.combine ~op:it.op (List.map ~f:(fun n -> Prop.compute ~n it.body) (List.range lower (Indexes.compute upper n+1)))

    module Output (S : String.S) =
      struct
        module X = XML(S)
        module C = Connective.Big.Output(S)
        module P = Prop.Output(S)
        let to_xml it_tag = 
          let it = find it_tag in
          X.node ~tag:(C.to_xml it.op) [ P.to_xml it.body ]
      end

    type syn_t = t
    module Set = MoreLabels.Set.Make(struct type t = syn_t let compare = total_compare end)
  end

include (Exposed : S)
