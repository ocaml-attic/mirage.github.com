(** Datatype and operations related to the indices of literals. *)
open Softcore

(** Signature of the module *)
module type S =
  sig
    (** The type of indexes *)
    type t

    (** {6 Comparisons } *)

    val equal         : t -> t -> bool
    val total_compare : t -> t -> int

    (** {6 Construtors} *)

    (** Create an index based on an int [n].
     * If [var=true] then create x+n.
     * If [var=false] then create n.
     * We do not take the name of the variable because it is not stored internally
     * (one could argue that this is a detail of implementation that should not appear in the signature;
     * I think on the contrary that taking a variable name but not using it - and thus losing it - can give raise to a misleading expected behaviour)
     *)
    val create : var:bool -> int -> t

    (** [of_int n] simply creates the index n. *)
    val of_int : int -> t

    (** {6 Destructors } *)

    val contains_variable : t -> bool

    (** If the index has the form x+n then return n.
     * If it has the form n then return n.
     *)
    val get_shift : t -> int

    (** {6 Useful functions} *)

    (** The sum of an index and a number. *)
    val add : t -> int -> t

    (** Shift an index by a given amonut. *)
    val shift : ?by:int -> t -> t

    (** {6 Substitutions } *)

    (** Computes the integer obtained from the substitution of the only variable of t (if any) by the input integer *)
    val compute : t -> int -> int
    val substitute_variable : t -> by:t -> t

    (** {6 Conversions from/to human indices} *)

    val to_human : var:string option -> t -> Human.indexes
    val of_human : Human.indexes -> t

    (** {6 Output to XML} *)
    (** Note: the output depends on the wanted encoding for strings, hence the functor. *)
    module Output : functor (S : String.S) -> sig val to_xml : t -> XML(S).t end

    (** {6 Map of indices} *)

    (** Artificial synonymous type for [t]. *)
    type idx = t

    (** Map module with some usual map functions *)
    module Map :
      sig
        include MoreLabels.Map.S with type key = idx
        val for_all : f:(key -> bool) -> 'a t -> bool
        val subset : eq:('a -> 'a -> bool) -> 'a t -> 'a t -> bool
      end
  end

(**/**)
module Exposed =
  struct
    module Indexes =
      struct
        type kind = Int | Sum
        type t = kind * int
        let create ~var n = (if var then Sum else Int), n
        let of_int n = Int, n

        let add (k,n) n' = (k,n+n')
        let shift ?(by=1) = function (Int,_) as x -> x | (Sum,n) -> (Sum,n+by)

        let contains_variable (k,n) = match k with Int -> false | Sum -> true
        let get_shift (_,n) = n

        exception Variable_expected
        let to_human ~var = function Int,n -> Human.Int n | Sum,n -> Human.Sum(Option.raise_if_none ~exc:Variable_expected var,n)
        let of_human = function Human.Int n -> Int,n | Human.Sum(_,n) -> Sum,n

        let substitute_variable (k,n) ~by:(k',n') =
          match k,k' with
          |Sum,Int  -> Int,n+n'
          |Sum,Sum -> Sum,n+n'
          |Int,_     -> Int,n

        let compute (k,n) n' = n+(match k with Sum -> n' | Int -> 0)

        let kind_equal k1 k2 = match k1,k2 with Int,Int |Sum,Sum -> true |Int,Sum |Sum,Int -> false
        let equal (k1,n1:t) (k2,n2:t) = kind_equal k1 k2 && n1 = n2

        let kind_compare k1 k2 = match k1,k2 with Int,Int |Sum,Sum -> 0 |Int,Sum -> -1 | Sum,Int -> 1
        let total_compare (k1,n1) (k2,n2) = if n1 = n2 then kind_compare k1 k2 else n1-n2
      end
    include Indexes

    module Output (S : String.S) =
      struct
        module X = XML(S)
        open X
        let to_xml (k,n) = !!(match k with Sum -> "sum" | Int -> "num") (S.of_int n)
      end

    type idx = t

    module Map =
      struct
        include MoreLabels.Map.Make(struct include Indexes let compare = total_compare end)
        let subset ~eq x y = for_all x ~f:(fun key data -> try eq data (find key y) with Not_found -> false)
        let for_all ~f = fold ~f:(fun ~key ~data:_ acc -> f key && acc) ~init:true
      end
  end

include (Exposed : S)
