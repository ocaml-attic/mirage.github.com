(** Datatype and operations related to "propositional" skeletons.
 * Namely:
 * - a skeleton is almost a schema except that the iterations do not carry any information about their bounds
 * (with regular schemata, all bounds are the same so there is no need to store them in every single iteration)
 * - and a skeleton is propositional if it contains no iteration
 *)
open Softcore

(** Signature of the module. *)
module type S =
  sig
    (** The type of propositional skeletons. *)
    type t

    (** {6 Constructors} *)

    val bot : t
    val top : t
    val construct : [ `Top | `Bot | `Op of Connective.t * t * t | `Lit of Literal.t ] -> t

    (** {6 Destructors} *)

    val destruct : t -> [ `Top | `Bot | `Op of Connective.t * t * t | `Lit of Literal.t ]
    val rec_destruct : t -> OpenProp.prop

    (** {6 Comparisons} *)

    val equal : t -> t -> bool
    val total_compare : t -> t -> int

    (** {6 Useful operations} *)

    (** Computes the negation of a skeleton. *)
    val opposite : t -> t

    (** Substitute the variable of a propositional skeleton, if any.
     * Note that there is at most one variable by the properties of regular schemata.
     **)
    val substitute_variable : by:Indexes.t -> t -> t

    (** Boolean algebra related simplifications. *)
    val algebraic_simplification : t -> t

    (** Computes the propositional formula corresponing to a given value of the parameter *)
    val compute : n:int -> t -> t

    (** Turns a propositional skeleton into conjonctive normal forma. *)
    val to_cnf : t -> t

    (** Shifts the index by a certain amount. *)
    val shift : ?by:int -> t -> t

    (** Combines n term using the connective [op]. *)
    val combine : op:Connective.Big.t -> t list -> t

    (** {6 Conversions from/to human schemas} *)

    (** @raise Nested_iteration_disallowed if the input contains nested iterations *)
    val of_human : Human.schema -> t
    exception Nested_iteration_disallowed of Human.iteration
    val to_human : var:string option -> t -> Human.schema

    (** {6 Output to XML} *)
    (** Note: the output depends on the wanted encoding for strings, hence the functor. *)
    module Output : functor (S : String.S) -> sig val to_xml : t -> XML(S).t end
  end

(**/**)
module Exposed =
  struct
    module O = OpenProp

    type t = O.prop

    let top = `Top
    let bot = `Bot

    let destruct = ident
    let rec_destruct = ident
    let construct = ident

    let rec to_human ~var x = O.to_human ~var (to_human ~var) x
    exception Nested_iteration_disallowed of Human.iteration
    let of_human x =
      ignore (Human.free_variable_of x);
      let rec of_human x = O.of_human of_human ~iteration_case:(fun it -> raise (Nested_iteration_disallowed it)) x in
      of_human x

    let rec equal x1 x2 = O.equal equal x1 x2
    let rec total_compare x1 x2 = O.total_compare total_compare x1 x2
    let rec opposite x = O.opposite opposite x
    let rec algebraic_simplification x = O.algebraic_simplification algebraic_simplification opposite x
    let rec compute ~n = O.compute compute ~n
    let combine = O.combine
    let rec substitute_variable ~by = O.substitute_variable substitute_variable ~by
    let rec shift ?by = O.shift shift ?by

    (* Eliminates redundant symbols (`Xor, `Equiv, `Imply) *)
    let canonized = function
      |`Op(con,f1,f2) -> Connective.canonized con f1 f2 ~opposite_formula:opposite ~op:(fun x y z -> `Op(x,y,z))
      |x -> x

    let rec to_cnf f = 
      let rec distr f1 f2 =
        match f1,f2 with
        |`Op(con,x2,x3),y when Connective.is_conj con -> `Op(con, distr x2 y, distr x3 y)
        |x,`Op(con,y2,y3) when Connective.is_conj con -> `Op(con, distr x y2, distr x y3)
        |x,y -> `Op(Connective.disj,x,y)
      in 
      match canonized f with
      |`Op(con,x,y) when Connective.is_conj con -> `Op(con,to_cnf x, to_cnf y)
      |`Op(con,x,y) when Connective.is_disj con -> distr (to_cnf x) (to_cnf y)
      |f' -> f'

    module Output (S : String.S) =
      struct
        module X = XML(S)
        module L = Literal.Output(S)
        module C = Connective.Output(S)
        let (!~) = S.of_string
        let rec to_xml = function
          |`Top -> X.leaf (S.of_string "true")
          |`Bot -> X.leaf (S.of_string "false")
          |`Lit l -> L.to_xml l
          |`Op(op,s1,s2) -> X.node ~tag:(C.to_xml_inner op) [ to_xml s1; to_xml s2; ]
      end
  end

include (Exposed : S)
