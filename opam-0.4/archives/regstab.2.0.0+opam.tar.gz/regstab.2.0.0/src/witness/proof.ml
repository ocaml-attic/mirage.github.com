(** Datatype and operations related to proof objects. *)
open Softcore open Helpers

module H = Human

(** [root] type. Defined apart in order to be reused in {!PreProof}. *)
type 'node root = {
    root : 'node;
    parameter : string option;
    bound_variable : string option;
    bounds: Bounds.t option;
  }

(** Main type of proofs. Quite self-explaining. *)
type t = node root
and node = block * symbol option * rule
and binary = Or | Equiv | Imply | Xor
and rule = 
  |Purity of Literal.t list * node
  |Top of node
  |And of active * active * node
  |Binary of binary * active * active * node * node
  |Unfold of ClosedArgument.t * node
  |Loop of symbol
  |Closed of ClosedArgument.t
and symbol = int
and block = Flat.t list * Constraint.t
and active = Flat.t

(** Signature of the module. *)
module type S =
  sig
    (** Conversion to the corresponding human type. *)
    val to_human : t -> H.proof

    (** Conversion of a block to the corresponding human type, i.e. sequent. *)
    val block_to_human : param:string option -> var:string option -> block -> H.left_sequent

    (** Output to XML. *)
    (** Note: the output depends on the wanted encoding for strings, hence the functor. *)
    module Output : functor (S : String.S) -> sig val to_xml : t -> XML(S).t end
  end

(**/**)
module Exposed =
  struct
    let rec map_symbols ~f =
      let (!) (b,s,r) = b, Option.map ~f s, map_symbols ~f r in
      function
        |Purity(lits,n) -> Purity(lits,!n)
        |Top n -> Top !n
        |And(a1,a2,n) -> And(a1,a2,!n)
        |Binary(rt,a1,a2,n1,n2) -> Binary(rt,a1,a2,!n1,!n2)
        |Unfold(arg,n) -> Unfold(arg,!n)
        |Loop s -> Loop (f s)
        |Closed arg -> Closed arg

    let shift_symbols = map_symbols ~f:succ
    let exchange_symbols ~s1 ~s2 = map_symbols ~f:(fun s -> if s = s1 then s2 else if s = s2 then s1 else s)

    let rec to_human { root = (bk,s,rule); parameter = param; bound_variable } =
      let ensure_no_symbol_is_zero_other_than_root =
        match s with 
        |None -> shift_symbols 
        |Some 0 -> ident 
        |Some n -> exchange_symbols ~s1:0 ~s2:n
      in
      (0, node_with_no_symbol_to_human ~param ~var:bound_variable ~bk ~rule:(ensure_no_symbol_is_zero_other_than_root rule)) :: !result

    and result = ref []

    and node_with_no_symbol_to_human ~param ~var ~bk ~rule =
      let bk = block_to_human ~param ~var bk in
      let node_to_human = node_to_human ~param ~var in
      match rule with
      |Purity(_,n) -> bk, H.(Unary(Rule.Purity, node_to_human n))
      |Top n -> bk, H.(Unary(Rule.Top, node_to_human n))
      |And(_,_,n) -> bk, H.(Unary(Rule.And, node_to_human n))
      |Binary(rt,_,_,n1,n2) -> bk, H.Binary(binary_to_human rt, node_to_human n1, node_to_human n2)
      |Unfold(arg,n) -> bk, H.(Binary(Rule.Unfold, closed_to_human ~param arg, node_to_human n))
      |Loop s -> bk, H.Link s
      |Closed _ -> bk, H.Axiom

    and binary_to_human = function Or -> H.Rule.Or | Xor -> H.Rule.Xor | Equiv -> H.Rule.Equiv | Imply -> H.Rule.Imply

    and node_to_human ~param ~var (bk,s,rule) =
      match s with
      |Some s ->
          result := (s, node_with_no_symbol_to_human ~var ~param ~bk ~rule) :: !result;
          block_to_human ~param ~var bk, H.Link s
      |None -> node_with_no_symbol_to_human ~param ~var ~bk ~rule

    and block_to_human ~param ~var (sks,cstr) =
      List.map sks ~f:(Flat.to_human ~param ~var ~bounds:(Some Bounds.default)), Constraint.to_human ~var:param cstr

    and closed_to_human ~param arg =
      let open ClosedArgument in
      let bk = 
        match arg with
        |False_formula -> [ Prop.to_human ~var:None Prop.bot ], H.True
        |Opposite_literals(l,c) ->
            let l = Literal.to_human ~var:param l in
            H.([ Lit l; Lit (complementary_lit l) ], Constraint.to_human ~var:param c)
        |Unsatisfiable_constraint _ -> [], H.False
        |Empty_disjunction c -> [ Prop.to_human ~var:None Prop.bot ], Constraint.to_human ~var:param c
      in
      bk, H.Axiom

    module Output (S : String.S) =
      struct
        module X = XML(S)
        module Cstr = Constraint.Output(S)
        module F = Flat.Output(S)
        module L = Literal.Output(S)
        open X

        let (!~) = S.of_string

        let rec to_xml ps =
          let attrs = 
            (match ps.parameter with None -> [] | Some x -> [ !~"parameter", !~x ])
            @
            (match ps.bound_variable with None -> [] | Some x -> [ !~"bound_var", !~x ])
            @
            (match ps.bounds with
            |None -> []
            |Some b -> [ !~"lower", S.of_int (Bounds.lower_of b); !~"upper", S.of_int (Bounds.upper_shift_of b); ])
          in
          X.node ~tag:!~"proof" ~attrs [ node_to_xml ps.root ]
        and node_to_xml ((_,cstr as bk),symb,rule) =
          let attrs = match symb with None -> [] | Some s -> [ !~"symbol", symbol_to_xml s ] in
          X.node ~tag:!~"node" ~attrs [ block_to_xml bk; rule_to_xml ~cstr rule; ]
        and block_to_xml (sks,cstr) = !"block" [ skeletons_to_xml sks; constraint_to_xml cstr; ]
        and skeletons_to_xml sks = !"skeleton_list" (List.map sks ~f:skeleton_to_xml)
        and skeleton_to_xml = F.to_xml
        and constraint_to_xml = Cstr.to_xml
        and rule_to_xml ~cstr = function
          |Purity(lits,n) -> !"purity_rule" (lits_to_xml ~acc:(node_to_xml n) lits)
          |Top n -> !"top_rule" [ node_to_xml n ]
          |And(a1,a2,n) -> !"and_rule" [ !"active" [ skeleton_to_xml a1 ]; !"active" [ skeleton_to_xml a2 ]; node_to_xml n ]
          |Unfold(arg,n) -> !"unfold_rule" [ closed_arg_to_xml ~cstr arg; node_to_xml n ]
          |Loop s -> X.node ~tag:!~"loop" ~attrs:[ !~"symbol", symbol_to_xml s ] []
          |Closed arg -> closed_arg_to_xml ~cstr arg
          |Binary(bin,a1,a2,n1,n2) ->
              let tag = match bin with Or -> "or_rule" | Equiv -> "equ_rule" | Imply -> "imp_rule" | Xor -> "xor_rule" in
              !tag [ !"active" [ skeleton_to_xml a1 ]; !"active" [ skeleton_to_xml a2 ]; node_to_xml n1; node_to_xml n2 ]
        and closed_arg_to_xml ~cstr arg =
          let open ClosedArgument in
          let rule =
            match arg with
            |Opposite_literals(lit,cstr) -> !"closed" [ lit_to_xml lit; lit_to_xml (Literal.opposite lit) ]
            |False_formula | Empty_disjunction _ -> !"bot_closed" []
            |Unsatisfiable_constraint(c1,c2) -> !"cstr_closed" [ constraint_to_xml c1; constraint_to_xml c2 ]
          in
          rule
        and lit_to_xml = L.to_xml
        and lits_to_xml ~acc lits = List.fold_left lits ~init:[acc] ~f:(fun acc lit -> lit_to_xml lit :: acc)
        and symbol_to_xml = S.of_int
      end
  end

include (Exposed : S)
