open Softcore

module type OUTPUT_INFO =
  sig
    module S : String.S
    val parameter : string option
    val bound_variable : string option
    val bounds : Bounds.t option
  end

module ClosedArgument =
  struct
    type t =
      |Opposite_literals of Literal.t * Constraint.t
      |Empty_disjunction of Constraint.t 
      |Unsatisfiable_constraint of Constraint.t * Constraint.t
      |False_formula

    let map ~f_lit ~f_cstr = function
      |False_formula -> False_formula
      |Empty_disjunction(c) -> Empty_disjunction(f_cstr c)
      |Opposite_literals(l,c) -> Opposite_literals(f_lit l, f_cstr c)
      |Unsatisfiable_constraint(c1,c2) -> Unsatisfiable_constraint(f_cstr c1, f_cstr c2)

    module Output (OI : OUTPUT_INFO) =
      struct
        module S = OI.S
        module H = Human.Output(S)
        open S
        let (!) = S.of_string
        let to_string = 
          function
          |False_formula -> !"false formula"
          |Empty_disjunction _ -> !"empty disjunction"
          |Unsatisfiable_constraint _ -> !"unsatisfiable constraint"
          |Opposite_literals(lit,cstr) -> !"opposite literals (literal " ^ H.lit_to_string (Literal.to_human ~var:OI.parameter lit) ^
              (match Constraint.is_equality cstr with
              |`Yes _ -> !", maybe using the constraint " ^ H.cstr_to_string (Constraint.to_human ~var:OI.parameter cstr)
              |`No -> S.empty
              ) ^ !")"
      end
  end

module ClosedOrNot =
  struct
    type 'a t = Closed of ClosedArgument.t | Non_closed of 'a
    let map ~f = function Closed a -> Closed a | Non_closed x -> Non_closed (f x)
  end

module IfNotSat =
  struct
    type 'a t = Sat | Not_sat of 'a
    let map ~f = function Sat -> Sat | Not_sat x -> Not_sat (f x)
  end

module SatOrClosedOrNeither =
  struct
    type ('a,'b) t = Sat of 'a | Closed | Neither of 'b
  end

module SatOrClosed =
  struct
    type 'a t = Sat of 'a | Closed of ClosedArgument.t
  end

module AtomicOrNot =
  struct
    type ('a,'b) t = Atomic of 'a | Non_atomic of 'b
  end
