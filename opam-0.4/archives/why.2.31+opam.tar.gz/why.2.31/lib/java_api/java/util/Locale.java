
import java.text.*;

class Locale {

}