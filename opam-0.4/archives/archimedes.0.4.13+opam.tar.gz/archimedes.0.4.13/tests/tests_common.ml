include Printf

let pi = 4. *. atan 1.
let dirs = ["./src"; "../src"; "_build/src"; "../../src"]

let w = 800.
let h = 600.

let description = "No description for this test"

