let _ = f 1 0o777 2

