class c = object
  method virtual m : ?x:int -> unit
end
