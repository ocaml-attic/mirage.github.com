type t = { l: p; r: n; z: b }
