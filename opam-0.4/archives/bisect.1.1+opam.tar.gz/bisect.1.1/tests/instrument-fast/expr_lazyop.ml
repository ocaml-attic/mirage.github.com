let f x y = (x > 0) && (y > 0)

let g x y = (x > 0) || (y > 0)
