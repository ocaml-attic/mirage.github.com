open TestGettext;;

let () = 
  Printf.eprintf (f_"%s\n") "abce";
  ()
;;
