/*
 * Copyright (c) 2011 Pedro Borges and contributors
 */

#ifndef CAML_ZMQ_FAIL_H_
#define CAML_ZMQ_FAIL_H_

void caml_zmq_raise_if(int condition);

#endif  /* CAML_ZMQ_FAIL_H_ */

