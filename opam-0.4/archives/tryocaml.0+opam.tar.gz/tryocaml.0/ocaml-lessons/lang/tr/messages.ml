"English", "Turkçe";

(* The rest needs to be done... *)
"Try OCaml", "Try OCaml";
"OCaml is a strongly typed functional language. It is concise and fast, enabling you to improve your coding efficiency while producing code with higher quality.",
"OCaml is a strongly typed functional language. It is concise and fast, enabling you to improve your coding efficiency while producing code with higher quality.";
"Click here to execute this code",
"Click here to execute this code";
