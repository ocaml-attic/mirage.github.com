"Try OCaml", "OCaml pas à pas";
"English", "Français";
"OCaml is a strongly typed functional language. It is concise and fast, enabling you to improve your coding efficiency while producing code with higher quality.",
"OCaml est un langage fonctionnel fortement typé. Concis et rapide, il vous permet d'améliorer votre productivité tout en produisant du code de meilleure qualité !";
"Click here to execute this code", "Cliquer pour exécuter le code";

  "Commands", "Commandes";
  "Effects", "Actions";
  "Enter / Return", "Entrée / Retour";
  "Submit code", "Exécuter le code";
  "Up / Down", "Haut / Bas";
  "Cycle through history", "Historique";
  "Shift + Enter", "Shift + Entrée";
  "Multiline edition", "Édition Multiligne";
  "Move to lesson 1", "Aller à la leçon 1";
  "Move to step 1 of the current lesson", "Aller à l'étape 1 de la leçon courante";
  "See available lessons", "Voir les leçons disponibles";
  "See available steps in the current lesson", "Voir les étapes disponibles dans la leçon courante";
  "Move to the next step", "Passer à l'étape suivante";
  "Move to the previous step", "Revenir à l'étape précédente";

  "You moved to lesson", "Vous êtes passé à la leçon";
  "step", "étape";
  "Congratulations", "Bravo";
  "You moved to the next lesson", "Vous êtes passé à la leçon suivante";
  "You moved to the next step", "Vous êtes passé à l'étape suivante";
  "All steps in lesson", "Toutes les étapes de la leçon";
  "All lessons", "Toutes les leçons";
  "Send", "Exécuter";
  "Clear", "Effacer";
  "Reset", "Ré-init";
  "Save", "Télécharger";
  "Lesson", "Leçon";
  "Step", "Étape";
