fun input output ->
  find_in "val abs : vect -> " output && find_in "_" input


