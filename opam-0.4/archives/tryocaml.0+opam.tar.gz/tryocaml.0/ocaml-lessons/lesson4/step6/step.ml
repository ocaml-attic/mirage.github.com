fun input output ->
  find_in "val head : 'a list -> 'a =" output
