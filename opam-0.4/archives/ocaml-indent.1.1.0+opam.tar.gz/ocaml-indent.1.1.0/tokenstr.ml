open Pos
open Reader
module Parser = Xparser
open Parser

type 'a desc = 
  | Cons of 'a * 'a t * in_channel option ref
  | Null of in_channel option ref

and 'a t = 'a desc lazy_t

type 'a info = {
  token : 'a;
  region : Region.t;
  substr : string;
  space : Region.t * string;
}

let close = function
  | lazy (Null icoptref | Cons (_, _, icoptref)) ->
      match !icoptref with
      | None -> ()
      | Some ic -> icoptref := None; close_in ic 

let of_channel ic = 
  let icoptref = ref (Some ic) in
  try
    let reader = LexReader.create_from_channel ic in
    let rec loop last_region = 
      let token = 
        try
          LexReader.lex reader Lexer.token 
        with
        | Lexer.Error (e, _loc) ->
            Format.eprintf "%a@." Lexer.report_error e;
            assert false
      in
      let region = LexReader.region reader in
      (* token's string *)
      let substr = LexReader.current_substring reader in

      let space_between = 
        let last_end = (snd last_region).Position.pos_cnum in
        LexReader.substring 
          reader last_end ((fst region).Position.pos_cnum - last_end)
      in
      let space_between_region = (snd last_region, fst region) in

      Cons ({ token; region; substr; space = space_between_region, space_between },
            begin match token with
            | EOF -> 
                let null = Lazy.lazy_from_val (Null icoptref) in
                close null;
                null
            | _ -> lazy (loop region)
            end,
            icoptref)
    in
    lazy (loop Region.zero)
  with
  | e -> raise e

let of_path path =
  let ic = open_in path in
  of_channel ic

let destr = function
  | lazy Null _ -> None
  | lazy (Cons (car, cdr, _)) -> Some (car, cdr)
