let _ = 
  begin match true with
  | true -> 1
  | false -> 2
  end

let _ = 
  begin prerr_endline "hello"; match true with
  | true -> 1
  | false -> 2
  end

let _ = 
  begin 
    prerr_endline "hello"; match true with
    | true -> 1
    | false -> 2
  end

let _ = 
  (match true with
  | true -> 1
  | false -> 2
  )

let _ = 
  match true with
  | true -> 1
  | false -> 2

let _ = 
  if true then match a with
  | true -> 1
  | false -> 2
  else
    0

let _ =
  let x = match true with
    | true -> 1
    | false -> 2
  in
  x

let _ =
  prerr_endline 1; let x = match true with
    | true -> 1
    | false -> 2
  in
  x
