let add_string ?(no_exit=false) t lnum s =
  try 
    let pos = String.index s '\n' in
    1, 
    2
  with
  | Not_found -> s, None
;;
