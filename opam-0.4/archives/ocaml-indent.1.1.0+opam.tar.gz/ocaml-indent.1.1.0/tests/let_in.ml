let x =
  let y = 10 in
  x
;;
