module type X = sig
  val x : int
end

module type X = 
  sig
    val x : int
  end



