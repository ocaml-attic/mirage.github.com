type t = {
  f : int;
  g : int 
}
