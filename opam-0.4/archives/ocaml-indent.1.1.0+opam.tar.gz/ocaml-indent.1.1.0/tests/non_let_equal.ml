let token state str at_the_head region (t : Parser.token) : State.t * State.t = 

  let pre_bases, post_bases = match t with
    | TYPE ->
        bases0, bases0 
          

    | TYPE when state.last_token = Some MODULE -> (* = is for when. Not for the let *)
        bases0, bases0 
      
          
    | TYPE ->
        let bases = unwind_top bases0 in
        bases, 
        { k = KType cols; indent = cols + 2; } :: bases
