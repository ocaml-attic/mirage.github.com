let f = function
  | X ->
      ( 1
      , 2 )
  | Y ->
      ( 1,
        2 )
  | Z ->
      1,
      2
  | W ->
      1,2,3
