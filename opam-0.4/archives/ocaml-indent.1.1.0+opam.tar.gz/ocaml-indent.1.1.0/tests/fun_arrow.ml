
let id = fun x y z w 
  ->  (* Mmmm, I have no idea for this *)
  x y z w

let id = fun x y 
             z w -> (* Mmmm, a TODO *)
  x


