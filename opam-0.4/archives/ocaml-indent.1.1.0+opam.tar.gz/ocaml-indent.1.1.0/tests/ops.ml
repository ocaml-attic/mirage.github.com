let x = 
  let y = 1
          + 2
          - 3
  and z = foo
  in
  y + z
