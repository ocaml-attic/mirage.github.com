let token state str at_the_head region (t : Parser.token) : State.t * State.t = function
  | DONE ->
      let rec f bases = match bases with
        | { k = (KDo cols ) } :: bs -> 
            fix cols, bs
        | [] -> [], []
        | _ :: bs -> f bs
      in
      f bases0

  | LPAREN ->
      if lparen_read_ahead line str then
        bases0, (* Comma was weaker than if/then *)
        { k = KParen cols; 
          indent = cols + 2; } 
        :: bases0
      else
        bases0, { k = KParen indent; indent = indent + 2; } :: bases0

