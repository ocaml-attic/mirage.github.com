let rec loop last_orig_region state str = match Tokenstr.destr str with
  | None -> state

  | Some (({Tokenstr.token = Parser.EOF} as i), _) ->
      let space_between = i.Tokenstr.space in
      Printer.add_string printer (Region.lnum last_orig_region) space_between;
      state
