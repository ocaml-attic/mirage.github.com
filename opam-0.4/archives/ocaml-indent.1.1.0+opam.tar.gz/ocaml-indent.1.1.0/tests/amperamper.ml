let x = 
  true 
  && 
    let x = false in x
