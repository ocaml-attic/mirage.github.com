(* OASIS_START *)
(* DO NOT EDIT (digest: 5311f5949d3d621c48ff9a788f5c80f3) *)
This is the README file for the ocaml-indent distribution.

OCaml indentation tool written in OCaml

See the files INSTALL.txt for building and installation instructions. 


(* OASIS_STOP *)
