open Stream_intf

(** Import the constructors *)
type 'a desc = 'a Spotlib.Stream.desc = 
  | Cons of 'a * 'a desc lazy_t
  | Null

module Make(P : Base) = struct

  open Spotlib.Stream
  include P

  type desc = (Elem.t option * Attr.t) Spotlib.Stream.desc
  type t = (Elem.t option * Attr.t) Spotlib.Stream.t (* None means EOS *)

  let cons_desc e attr v = Cons ((Some e,attr), v)
  let null_desc attr = Cons ((None, attr), Spotlib.Stream.null)
  let null attr = Lazy.lazy_from_val (null_desc attr)

  let peek = function
    | lazy Cons ((Some elem, _), t') -> Some (elem, t')
    | _ -> None

  let is_null = is_null
    
  let to_list t = 
    let rec to_list st = function
      | lazy Cons ((Some elem, _), t) -> to_list (elem :: st) t
      | _ -> List.rev st
    in
    to_list [] t

  let rec iter f = function
    | lazy Cons ((Some elem, _), t) -> f elem; iter f t
    | _ -> ()

  let rec fold_right f lst st = match lst with
    | lazy Cons ((Some v, _), lst') -> f v (fold_right f lst' st)
    | _ -> st

  let rec map f lst = lazy (match lst with
    | lazy Cons ((Some v, _pos), lst') -> Cons (f v, map f lst')
    | _ -> Null)

  (* [t2] must be a postfix of [t1] otherwise, it loops forever *)
  let rev_between t1 t2 =
    let rec loop st t =
      if t == t2 then st (* CR jfuruse: we cannot always use pointer eq *)
      else 
        match t with
        | lazy Cons ((Some elem, _), t') -> loop (elem::st) t'
        | _ -> st
    in
    loop [] t1

  let between t1 t2 = List.rev (rev_between t1 t2)

  let attr = function
    | lazy Cons ((_, attr), _) -> attr
    | _ -> assert false

  let position s = Attr.position (attr s)

end
