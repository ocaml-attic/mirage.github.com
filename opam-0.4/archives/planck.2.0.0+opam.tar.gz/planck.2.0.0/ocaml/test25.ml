let b = z >>= w
