let x = "\3"

(* "\2" *)

let x = 1

