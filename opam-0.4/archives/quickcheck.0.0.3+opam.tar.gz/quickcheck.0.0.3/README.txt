(* OASIS_START *)
(* DO NOT EDIT (digest: b291207cad5e1569bf210ef8cb07eb48) *)
This is the README file for the ocaml-quickcheck distribution.

Ocaml port of haskell QuickCheck -- probabilistic testing

See the files INSTALL.txt for building and installation instructions. See the
file LICENSE for copying conditions. 


(* OASIS_STOP *)

SEE README.md
