(** Type of S-expressions *)
type t = Atom of string | List of t list
