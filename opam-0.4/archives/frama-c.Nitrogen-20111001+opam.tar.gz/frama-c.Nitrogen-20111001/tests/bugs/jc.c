
//@ requires \valid(p);
void g(int*p);


void f(int *a){
  g(a);
} 
