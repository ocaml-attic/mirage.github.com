/* run.config
   EXECNOW: make -s tests/slicing/select_simple.opt
   CMD: tests/slicing/select_simple.opt
   OPT: -check -deps -journal-disable
*/

/* dummy source file in order to test select_simple.ml */

#include "tests/slicing/simple_intra_slice.c"
