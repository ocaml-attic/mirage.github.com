/* run.config
   STDOPT: +"tests/spec/merge_bts938_1.c"
*/

#include "tests/spec/merge_bts938.h"
