/*@ type t; */
/*@ logic t create(int x); */
/*@ logic t1 create(int y); // error: type does not exist
*/
