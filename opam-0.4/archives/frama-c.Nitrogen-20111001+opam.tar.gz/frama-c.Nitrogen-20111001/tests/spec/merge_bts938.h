extern int tab[10];
//@ ensures tab == {tab \with [0]= (int)0} ;
int main(void) ;
