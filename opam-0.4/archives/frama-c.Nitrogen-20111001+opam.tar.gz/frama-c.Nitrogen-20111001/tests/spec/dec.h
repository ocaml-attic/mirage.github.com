#ifndef __DEC
#define __DEC

/*@ axiomatic S { logic integer F(integer x) ; } */

//@ logic integer X = 42;

#endif
