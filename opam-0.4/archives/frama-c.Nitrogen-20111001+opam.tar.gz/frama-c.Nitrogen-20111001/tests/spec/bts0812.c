/*@ lemma fib_3: \true; // proved automatically */
/*@ lemma fib_46: \true; */

/*@ assigns \nothing;
// Bla */
void main() {
}

