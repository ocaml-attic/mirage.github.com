/* run.config
   DONTRUN: linked with multiple_decl_def_1.c which is the real test.
*/
/*@ requires y <= 0; */
int f(int y) { return y; }
