(* Checks that even Jessie-specific normalization does not create spurious
   warnings.
 *)
Cabs2cil.setDoAlternateConditional ();;
