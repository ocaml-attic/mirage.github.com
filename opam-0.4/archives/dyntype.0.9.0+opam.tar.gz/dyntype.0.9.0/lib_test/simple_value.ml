open Dyntype

type t = int with value
