* X-Rate-Limit support in the Monad.

* Would be very useful if ATDgen could convert to/from normal string
  as well as JSON for variants.  The Github API takes strings as
  URI parameters for requests, which need to be manually converted
  at present.
