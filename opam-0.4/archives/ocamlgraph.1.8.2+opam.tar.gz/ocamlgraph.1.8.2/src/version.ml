let version = "1.8.2"
let date = "Sat May 12 10:53:39 CEST 2012"
