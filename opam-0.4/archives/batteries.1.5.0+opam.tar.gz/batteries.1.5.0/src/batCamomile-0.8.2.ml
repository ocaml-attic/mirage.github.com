include CamomileLibrary.Make(CamomileLibraryDyn.Config)
