print_string (String.escaped Sys.argv.(1))
