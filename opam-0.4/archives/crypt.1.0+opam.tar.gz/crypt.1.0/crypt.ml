external crypt: string -> string -> string = "ml_crypt"
