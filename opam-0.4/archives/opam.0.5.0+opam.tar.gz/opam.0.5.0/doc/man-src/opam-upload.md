% OPAM-UPLOAD(1) Opam Manual | Version 0.4
% OCamlPro
% September 03, 2012

# NAME

opam-upload - Upload a new package to a remote repository

# SYNOPSIS

*opam upload* -opam \<opam-file\> -descr \<descr-file\> -archive
 \<name.version.tar.gz\> [-repo \<repository\>]

# DESCRIPTION

TODO: add description

# PARAMETERS

-opam \<opam-file\>
:   Specify the .opam file to use.

-descr \<descr-file\>
:   Specify the .descr file to use.

-archive \<name.version.tar.gz\>
:   

# SEE ALSO

**opam-remote**(1) **opam-upgrade**(1)

# OPAM

Part of the opam(1) suite
