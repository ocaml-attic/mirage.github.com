(*
 * This file is part of Bolt.
 * Copyright (C) 2009-2012 Xavier Clerc.
 *
 * Bolt is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Bolt is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *)

(* Definitions *)

let magic_trace = "Paje trace\000(magic\001)"

let magic_kind = "Paje kind\000(magic\001)"

let t = magic_trace

let () = Utils.paje_t := t

type properties = (string * string) list

type field_type =
  | Date
(*  | Int not used *)
  | Double
(*  | Hex not used *)
  | String

let string_of_field_type = function
  | Date -> "date"
(*  | Int -> "int" not used *)
  | Double -> "double"
(*  | Hex -> "hex" not used *)
  | String -> "string"

type event = {
    event_name : string;
    event_id : int;
    event_fields : (string * field_type) list;
  }

let event_def =
  let id = ref 0 in
  fun name l ->
    incr id;
    { event_name = name;
      event_id = !id;
      event_fields = l; }

let predefined_events = [
  event_def "PajeDefineContainerType"
    ["Alias", String; "ContainerType", String; "Name", String];
  event_def "PajeCreateContainer"
    ["Time", Date; "Alias", String; "Type", String; "Container", String; "Name", String];
  event_def "PajeDestroyContainer"
    ["Time", Date; "Name", String; "Type", String];
  event_def "PajeDefineEventType"
    ["Name", String; "ContainerType", String; "Alias", String];
  event_def "PajeDefineStateType"
    ["Name", String; "ContainerType", String; "Alias", String];
  event_def "PajeDefineVariableType"
    ["Name", String; "ContainerType", String; "Alias", String];
  event_def "PajeDefineLinkType"
    ["Name", String; "ContainerType", String; "SourceContainerType", String; "DestContainerType", String; "Alias", String];
  event_def "PajeDefineEntityValue"
    ["Name", String; "EntityType", String; "Alias", String];
  event_def "PajeNewEvent"
    ["Time", Date; "Type", String; "Container", String; "Value", String];
  event_def "PajeSetState"
    ["Time", Date; "Type", String; "Container", String; "Value", String];
  event_def "PajePushState"
    ["Time", Date; "Type", String; "Container", String; "Value", String];
  event_def "PajePopState"
    ["Time", Date; "Type", String; "Container", String];
  event_def "PajeSetVariable"
    ["Time", Date; "Type", String; "Container", String; "Value", Double];
  event_def "PajeAddVariable"
    ["Time", Date; "Type", String; "Container", String; "Value", Double];
  event_def "PajeSubVariable"
    ["Time", Date; "Type", String; "Container", String; "Value", Double];
  event_def "PajeStartLink"
    ["Time", Date; "Type", String; "Container", String; "SourceContainer", String; "Value", String; "Key", String];
  event_def "PajeEndLink"
    ["Time", Date; "Type", String; "Container", String; "DestContainer", String; "Value", String; "Key", String]
]

(* Predefined events: trace definition *)

let define_container_type ~name ?(alias=name) ?(container_type="0") l =
  [magic_kind, "PajeDefineContainerType";
   "Name", name;
   "Alias", alias;
   "ContainerType", container_type]
  @ l

let define_event_type ~name ?(alias=name) ~container_type l =
  [magic_kind, "PajeDefineEventType";
   "Name", name;
   "Alias", alias;
   "ContainerType", container_type]
  @ l

let define_state_type ~name ?(alias=name) ~container_type l =
  [magic_kind, "PajeDefineStateType";
   "Name", name;
   "Alias", alias;
   "ContainerType", container_type]
  @ l

let define_variable_type ~name ?(alias=name) ~container_type l =
  [magic_kind, "PajeDefineVariableType";
   "Name", name;
   "Alias", alias;
   "ContainerType", container_type]
  @ l

let define_link_type ~name ?(alias=name) ~container_type ~source_container_type ~dest_container_type l =
  [magic_kind, "PajeDefineLinkType";
   "Name", name;
   "Alias", alias;
   "ContainerType", container_type;
   "SourceContainerType", source_container_type;
   "DestContainerType", dest_container_type]
  @ l

let define_entity_value ~name ?(alias=name) ~entity_type l =
  [magic_kind, "PajeDefineEntityValue";
   "Name", name;
   "Alias", alias;
   "EntityType", entity_type]
  @ l


(* Predefined events: trace recording *)

let create_container ~name ?(alias=name) ~typ ?(container="0") l =
  [magic_kind, "PajeCreateContainer";
   "Name", name;
   "Alias", alias;
   "Type", typ;
   "Container", container]
  @ l

let destroy_container ~name ~typ l =
  [magic_kind, "PajeDestroyContainer";
   "Name", name;
   "Type", typ]
  @ l


let new_event ~typ ~container ~value l =
  [magic_kind, "PajeNewEvent";
   "Type", typ;
   "Container", container;
   "Value", value]
  @ l

let set_state ~typ ~container ~value l =
  [magic_kind, "PajeSetState";
   "Type", typ;
   "Container", container;
   "Value", value]
  @ l

let push_state ~typ ~container ~value l =
  [magic_kind, "PajePushState";
   "Type", typ;
   "Container", container;
   "Value", value]
  @ l

let pop_state ~typ ~container l =
  [magic_kind, "PajePopState";
   "Type", typ;
   "Container", container]
  @ l

let set_variable ~typ ~container ~value l =
  [magic_kind, "PajeSetVariable";
   "Type", typ;
   "Container", container;
   "Value", string_of_float value]
  @ l

let add_variable ~typ ~container ~value l =
  [magic_kind, "PajeAddVariable";
   "Type", typ;
   "Container", container;
   "Value", string_of_float value]
  @ l

let sub_variable ~typ ~container ~value l =
  [magic_kind, "PajeSubVariable";
   "Type", typ;
   "Container", container;
   "Value", string_of_float value]
  @ l

let start_link ~typ ~container ~source_container ~value ~key l =
  [magic_kind, "PajeStartLink";
   "Type", typ;
   "Container", container;
   "SourceContainer", source_container;
   "Value", value;
   "Key", key]
  @ l

let end_link ~typ ~container ~dest_container ~value ~key l =
  [magic_kind, "PajeEndLink";
   "Type", typ;
   "Container", container;
   "DestContainer", dest_container;
   "Value", value;
   "Key", key]
  @ l


(* Layout elements *)

let string_of_event ev =
  let field_def (nam, typ) =
    Printf.sprintf "%%\t%s\t%s" nam (string_of_field_type typ) in
  ((Printf.sprintf "%%EventDef\t%s\t%d" ev.event_name ev.event_id)
   :: (List.map field_def ev.event_fields))
  @ ["%EndEventDef"]

let extract_kind l = List.partition (fun (x, _) -> x = magic_kind) l

let render e =
  let default = function
    | Date -> string_of_float ((float e.Event.relative) /. 1000.)
(*    | Int -> "0" not used *)
    | Double -> "0.0"
(*    | Hex -> "00" not used *)
    | String -> "\"\"" in
  let make_fields id fields properties =
    let res =
      List.map
        (fun (nam, typ) ->
          try
            let res = List.assoc nam properties in
            if typ = String then Printf.sprintf "%S" res else res
          with Not_found -> default typ)
        fields in
    let res = (string_of_int id) :: res in
    String.concat " " res in
  if e.Event.message = magic_trace then
    try
      let kind, rest = extract_kind e.Event.properties in
      match kind with
      | [_, kind] ->
          let def =
            List.find
              (fun ed -> kind = ed.event_name)
              predefined_events in
          make_fields def.event_id def.event_fields rest
      | _ -> ""
    with _ -> ""
  else
    ""

let header = List.concat (List.map string_of_event predefined_events)

let layout = header, [], render

let layout_noheader = [], [], render

let () =
  List.iter
    (fun (x, y) -> Layout.register x y)
    [ "paje",          layout ;
      "paje_noheader", layout_noheader ]


(* Functorial interface *)

module type Definitions = sig
  val logger : string
  val level : Level.t
  type container_type
  val container_types : (container_type * string * string * (container_type option)) list
  type event_type
  val event_types : (event_type * string * string * container_type) list
  type state_type
  val state_types : (state_type * string * string * container_type) list
  type variable_type
  val variable_types : (variable_type * string * string * container_type) list
  type link_type
  val link_types : (link_type * string * string * container_type * container_type * container_type) list
end

module type S = sig
  val t : string
  type properties = (string * string) list
  type container_type
  type event_type
  type state_type
  type variable_type
  type link_type
  val create_container : name:string -> ?alias:string -> typ:container_type -> ?container:string -> properties -> properties
  val destroy_container : name:string -> typ:container_type -> properties -> properties
  val new_event : typ:event_type -> container:string -> value:string -> properties -> properties
  val set_state : typ:state_type -> container:string -> value:string -> properties -> properties
  val push_state : typ:state_type -> container:string -> value:string -> properties -> properties
  val pop_state : typ:state_type -> container:string -> properties -> properties
  val set_variable : typ:variable_type -> container:string -> value:float -> properties -> properties
  val add_variable : typ:variable_type -> container:string -> value:float -> properties -> properties
  val sub_variable : typ:variable_type -> container:string -> value:float -> properties -> properties
  val start_link : typ:link_type -> container:string -> source_container:string -> value:string -> key:string -> properties -> properties
  val end_link : typ:link_type -> container:string -> dest_container:string -> value:string -> key:string -> properties -> properties
end

module Make (D : Definitions) = struct
  let t = t
  type properties = (string * string) list
  type container_type = D.container_type
  type event_type = D.event_type
  type state_type = D.state_type
  type variable_type = D.variable_type
  type link_type = D.link_type

  let containers = Hashtbl.create 17
  let events = Hashtbl.create 17
  let states = Hashtbl.create 17
  let variables = Hashtbl.create 17
  let links = Hashtbl.create 17

  let get_container typ =
    try
      Hashtbl.find containers typ
    with _ -> failwith "invalid container type"

  let get_event typ =
    try
      Hashtbl.find events typ
    with _ -> failwith "invalid event type"

  let get_state typ =
    try
      Hashtbl.find states typ
    with _ -> failwith "invalid state type"

  let get_variable typ =
    try
      Hashtbl.find variables typ
    with _ -> failwith "invalid variable type"

  let get_link typ =
    try
      Hashtbl.find links typ
    with _ -> failwith "invalid link type"

  let () =
    (* containers *)
    List.iter
      (fun (x, name, alias, parent) ->
        Hashtbl.add containers x name;
        let container_type = match parent with
        | Some x ->
            (try
              Hashtbl.find containers x
            with _ -> failwith "invalid container parent")
        | None -> "0" in
        let properties = define_container_type ~name ~alias ~container_type [] in
        Logger.log D.logger D.level ~properties t)
      D.container_types;
    (* events *)
    List.iter
      (fun (x, name, alias, container_type) ->
        Hashtbl.add events x name;
        let container_type = get_container container_type in
        let properties = define_event_type ~name ~alias ~container_type [] in
        Logger.log D.logger D.level ~properties t)
      D.event_types;
    (* states *)
    List.iter
      (fun (x, name, alias, container_type) ->
        Hashtbl.add states x name;
        let container_type = get_container container_type in
        let properties = define_state_type ~name ~alias ~container_type [] in
        Logger.log D.logger D.level ~properties t)
      D.state_types;
    (* variables *)
    List.iter
      (fun (x, name, alias, container_type) ->
        Hashtbl.add variables x name;
        let container_type = get_container container_type in
        let properties = define_variable_type ~name ~alias ~container_type [] in
        Logger.log D.logger D.level ~properties t)
      D.variable_types;
    (* links *)
    List.iter
      (fun (x, name, alias, container_type, source_container_type, dest_container_type) ->
        Hashtbl.add links x name;
        let container_type = get_container container_type in
        let source_container_type = get_container source_container_type in
        let dest_container_type = get_container dest_container_type in
        let properties = define_link_type ~name ~alias ~container_type ~source_container_type ~dest_container_type [] in
        Logger.log D.logger D.level ~properties t)
      D.link_types

  let create_container ~name ?(alias=name) ~typ ?(container="0") l =
    let typ = get_container typ in
    create_container ~name ~alias ~typ ~container l

  let destroy_container ~name ~typ l =
    let typ = get_container typ in
    destroy_container ~name ~typ l

  let new_event ~typ ~container ~value l =
    let typ = get_event typ in
    new_event ~typ ~container ~value l

  let set_state ~typ ~container ~value l =
    let typ = get_state typ in
    set_state ~typ ~container ~value l

  let push_state ~typ ~container ~value l =
    let typ = get_state typ in
    push_state ~typ ~container ~value l

  let pop_state ~typ ~container l =
    let typ = get_state typ in
    pop_state ~typ ~container l

  let set_variable ~typ ~container ~value l =
    let typ = get_variable typ in
    set_variable ~typ ~container ~value l

  let add_variable ~typ ~container ~value l =
    let typ = get_variable typ in
    add_variable ~typ ~container ~value l

  let sub_variable ~typ ~container ~value l =
    let typ = get_variable typ in
    sub_variable ~typ ~container ~value l

  let start_link ~typ ~container ~source_container ~value ~key l =
    let typ = get_link typ in
    start_link ~typ ~container ~source_container ~value ~key l

  let end_link ~typ ~container ~dest_container ~value ~key l =
    let typ = get_link typ in
    end_link ~typ ~container ~dest_container ~value ~key l

end
