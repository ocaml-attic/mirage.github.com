let [_; x] = 1
