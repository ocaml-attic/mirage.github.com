cryptokit-sha512
================

Xavier Leroy’s cryptokit upgraded with Vincent Hanquez’s ocaml-sha sha512 code