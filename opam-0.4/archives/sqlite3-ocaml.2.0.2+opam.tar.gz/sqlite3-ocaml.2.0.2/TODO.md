1. More testing

2. An even higher level function for execution of queries in a more
   convenient way.  It should handle busy queries and expired statements
   automatically.

3. TODO: Add the following wrappers:

     a. Better SQL Function support (aggregating ones)
     b. Collation support
     c. Authorization support
     d. Trace/profile support
     e. progress handler support
     f. commit hook support
     g. global_recover, get_autocommit, db_handle, temp_directory
     h. encryption support (not in SQLite anyway)
