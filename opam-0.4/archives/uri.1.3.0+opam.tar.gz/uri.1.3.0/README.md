RFC3968 URI parsing library.

Build requirements:
* [ocaml-re](http://github.com/avsm/ocaml-re) regular expression library.
* [oUnit](http://ounit.forge.ocamlcore.org/) unit testing library.

Much assistance for the regular expressions from:
<http://jmrware.com/articles/2009/uri_regexp/URI_regex.html>

TODO (at least):

+ path normalisation (`a/b/..` to `a/`)
