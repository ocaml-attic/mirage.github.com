(* OASIS_START *)
(* DO NOT EDIT (digest: 3cbedcc03bd13d22867ed072aab85e5b) *)
This is the README file for the weberizer distribution.

HTML templating system with various exports.

Template allows HTML templates to be compiled into OCaml modules.

See the files INSTALL.txt for building and installation instructions. 

Home page: https://github.com/Chris00/weberizer


(* OASIS_STOP *)
