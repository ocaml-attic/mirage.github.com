(*
  Copyright 2010 Gerd Stolpmann

  This file is part of Plasma, a distributed filesystem and a
  map/reduce computation framework. Unless you have a written license
  agreement with the copyright holder (Gerd Stolpmann), the following
  terms apply:

  Plasma is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  Plasma is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with Foobar.  If not, see <http://www.gnu.org/licenses/>.

*)
(* $Id: nn_push.ml 488 2011-10-25 21:29:23Z gerd $ *)

open Uq_engines.Operators

let dlogf = Plasma_util.dlogf

module Nslave_proxy = Pfs_rpcapi_clnt.Make'Nameslave(Rpc_proxy.ManagedClient)

type client = Rpc_proxy.ManagedClient.mclient

type commit_id = int

let create_client conn cauth tmo esys =
  dlogf
    "Nn_push.create_client tmo=%f" tmo;
  let mclient_config =
    Rpc_proxy.ManagedClient.create_mclient_config
      ~programs:[ Pfs_rpcapi_clnt.Nameslave.V1._program ]
      ~msg_timeout:tmo
      ~msg_timeout_is_fatal:true
      ~initial_ping:true
      ~auth_methods:(Pfs_auth.rpc_proxy_auth_methods cauth true)
      () in
  let mclient =
    Rpc_proxy.ManagedClient.create_mclient
      mclient_config
      conn
      esys in
  mclient

let trigger_shutdown mclient =
  Rpc_proxy.ManagedClient.trigger_shutdown mclient (fun () -> ())

let rec wait_until_ready_e conn esys =
  dlogf
    "Nn_push.wait_until_ready_e";
  let mclient_config =
    Rpc_proxy.ManagedClient.create_mclient_config
      ~programs:[ Pfs_rpcapi_clnt.Nameslave.V1._program ]
      ~msg_timeout:1.0
      () in
  let mclient =
    Rpc_proxy.ManagedClient.create_mclient
      mclient_config
      conn
      esys in
  Uq_engines.meta_engine
    (Plasma_util.rpc_engine mclient Nslave_proxy.V1.null'async ())
  ++ (fun st ->
	Rpc_proxy.ManagedClient.trigger_shutdown mclient (fun () -> ());
	match st with
	  | `Done() -> eps_e (`Done()) esys
	  | _ ->
	      Uq_engines.delay_engine 
		1.0
		(fun () ->  wait_until_ready_e conn esys)
		esys
     )


let begin_transaction_e mclient commit_id cn rev =
  try
    let l = Nn_db.ds_cache_contents() in
    Plasma_util.rpc_engine
      mclient Nslave_proxy.V1.begin_transaction'async (commit_id,cn,rev)
    ++ (fun () ->
	  (* FIXME: questionable code *)
	  let l' =
	    Array.of_list (List.map Nn_datastores.to_xdr l) in
	  Plasma_util.rpc_engine
	    mclient Nslave_proxy.V1.set_ds_cache'async l'
       )
  with err ->
    eps_e (`Error err) (Rpc_proxy.ManagedClient.event_system mclient)
      
let prepare_commit_e mclient commit_id =
  Plasma_util.rpc_engine mclient Nslave_proxy.V1.prepare_commit'async commit_id

let commit_e mclient commit_id =
  Plasma_util.rpc_engine mclient Nslave_proxy.V1.commit'async commit_id

let push_e m mclient commit_id =
  match m with
    | `Datastore_upd(id,identity,size,enabled) ->
	Plasma_util.rpc_engine 
	  mclient 
	  Nslave_proxy.V1.push_datastore_upd'async
	  (commit_id,id,identity,size,enabled)
    | `Datastore_del id ->
	Plasma_util.rpc_engine 
	  mclient 
	  Nslave_proxy.V1.push_datastore_del'async
	  (commit_id,id)
    | `Revision_upd(upd_commit_id,revstr) ->
	assert(upd_commit_id = commit_id);
	Plasma_util.rpc_engine 
	  mclient 
	  Nslave_proxy.V1.push_revision_upd'async
	  (commit_id,revstr)
    | `Revision_clear ->
	Plasma_util.rpc_engine 
	  mclient 
	  Nslave_proxy.V1.push_revision_clear'async
	  (commit_id)
    | `Blockalloc_upd(datastore,blkidx,blkmap) ->
	Plasma_util.rpc_engine 
	  mclient 
	  Nslave_proxy.V1.push_blockalloc_upd'async
	  (commit_id,datastore,blkidx,blkmap)
    | `Inode_ins(id,ii) ->
	Plasma_util.rpc_engine
	  mclient
	  Nslave_proxy.V1.push_inode_ins'async
	  (commit_id,id,ii)
    | `Inode_upd(id,ii) ->
	Plasma_util.rpc_engine
	  mclient
	  Nslave_proxy.V1.push_inode_upd'async
	  (commit_id,id,ii)
    | `Inode_upd_time(id,mtime,ctime) ->
	Plasma_util.rpc_engine
	  mclient
	  Nslave_proxy.V1.push_inode_upd_time'async
	  (commit_id,id,mtime,ctime)
    | `Inode_set_anonymous id ->
	Plasma_util.rpc_engine
	  mclient
	  Nslave_proxy.V1.push_inode_set_anonymous'async
	  (commit_id,id)
    | `Inode_del id ->
	Plasma_util.rpc_engine
	  mclient
	  Nslave_proxy.V1.push_inode_del'async
	  (commit_id,id)
    | `Inodeblocks_ins (inode,blist) ->
	let bi_list = Nn_blocklist.to_blockinfo_list blist in
	Plasma_util.rpc_engine
	  mclient
	  Nslave_proxy.V1.push_inodeblocks_ins'async
	  (commit_id,inode,Array.of_list bi_list)
    | `Inodeblocks_del(inode,blkidx,len) ->
	Plasma_util.rpc_engine
	  mclient
	  Nslave_proxy.V1.push_inodeblocks_del'async
	  (commit_id,inode,blkidx,len)
    | `Names_ins(dir_inode,name,inode) ->
	Plasma_util.rpc_engine
	  mclient
	  Nslave_proxy.V1.push_names_ins'async
	  (commit_id,dir_inode,name,inode)
    | `Names_del(dir_inode,name) ->
	Plasma_util.rpc_engine
	  mclient
	  Nslave_proxy.V1.push_names_del'async
	  (commit_id,dir_inode,name)
    | `Admin_table_put(key,contents) ->
	Plasma_util.rpc_engine
	  mclient
	  Nslave_proxy.V1.push_admin_table'async
	  (commit_id,key,contents)
	

