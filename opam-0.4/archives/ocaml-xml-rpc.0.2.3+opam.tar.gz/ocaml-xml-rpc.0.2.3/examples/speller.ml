(* Created by oxridl from 'speller.idl' on Fri Mar 12 11:34:15 2004 *)
open XmlRPCTypes
let spellCheck_stub = new XmlRPCClient.remote "http://www.stuffeddog.com/speller/speller-rpc.cgi" "speller.spellCheck"
let spellCheck a1 = 
 let retval = spellCheck_stub#call [`String a1] in
ml_of_structarray retval

