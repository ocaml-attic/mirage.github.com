(*
    Ocaml XML-RPC support.
    Copyright (C) 2004 Shawn Wagner <raevnos@pennmush.org>

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*)

(** Handle XML-RPC requests using Ocaml-HTTP *)

class http_source (daemon:Http_types.daemon) = object (self)

  val mutable conn = None

  method private con =
    match conn with
      | Some c -> c
      | None -> raise (XmlRPCServer.Error ("Invalid use of HttpSource", -1))

  method get_request () = 
    let req, conne = daemon#getRequest in
      conn <- Some conne;
      req#body

  method send_reply body =
    let con = self#con in
    let resp = new Http_response.response
		 ~body ~headers:["Content-Length",
				 string_of_int (String.length body);
				 "Content-Type", "text/xml";
				 "Server", XmlRPCServer.server;
				 "Date", Time.time_string (Time.time ())
				] () in
      con#respond_with resp;
      (*      con#close; (* Calling close now causes an exception when
	      the object's finalization function gets called on GC *) *)
      conn <- None;
      ()
end

(** Return a new handler that listens on the given port. *)
let make ?addr ?port () = 
  XmlRPCServer.make (new http_source (new Http_daemon.daemon ?addr ?port ()))
  
