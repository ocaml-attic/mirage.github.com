(* Configuration to e.g. specify the path to the Cairo library. *)

(* Complete CFLAGS and CLIBS the the default values do not work. *)

let cairo_cflags = [] (* e.g. ["-I/usr/include/cairo"] *)
let cairo_clibs  = [] (* e.g. ["-L/usr/lib";  "-lcairo"] *)

let gtk_cflags = []
