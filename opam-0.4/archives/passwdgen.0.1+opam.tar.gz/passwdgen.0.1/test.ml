open Passwdgen

let config = init ();;
let mypasswd = passwdgen config;;
print_endline mypasswd;;
