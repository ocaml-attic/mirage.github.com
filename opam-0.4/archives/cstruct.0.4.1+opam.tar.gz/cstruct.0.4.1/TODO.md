Blocking a 1.0 release:

* Figure out how to make the Xen build system work with OASIS
* Document the signatures for ocamldoc
* Bounds checking elimination at attach-time (possibly interface-breaking)

Nice to have:

* Performance tests vs bitstring
