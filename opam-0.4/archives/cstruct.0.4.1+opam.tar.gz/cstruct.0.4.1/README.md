WIP: see 
https://github.com/avsm/mirage/issues/94

The `unix` directory contains a standard OCaml version,
and the `xen` directory bundles a custom `Bigarray` module
with no dependency on UNIX (no `map_file` function).
