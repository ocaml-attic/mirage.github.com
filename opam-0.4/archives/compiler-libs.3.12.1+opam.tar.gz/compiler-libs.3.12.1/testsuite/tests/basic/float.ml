Printf.printf "1./.0. = %f\n" (1.0 /. 0.0);;
