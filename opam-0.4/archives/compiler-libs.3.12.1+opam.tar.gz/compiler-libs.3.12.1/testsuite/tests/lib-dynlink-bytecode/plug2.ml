external stub2: unit -> unit = "stub2"


let () = stub2 ()
