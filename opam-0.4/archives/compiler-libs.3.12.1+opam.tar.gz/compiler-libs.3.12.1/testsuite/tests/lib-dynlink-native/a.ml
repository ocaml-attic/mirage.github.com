let x = ref 0
let u = Random.int 1000

let () =
  Printf.printf "A is running (%i)\n%!" u
