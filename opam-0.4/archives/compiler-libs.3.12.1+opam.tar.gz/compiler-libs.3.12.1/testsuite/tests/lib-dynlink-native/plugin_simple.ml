let facts = [ (Random.int 4) ]

let () = print_endline "COUCOU"; print_char '\n'
