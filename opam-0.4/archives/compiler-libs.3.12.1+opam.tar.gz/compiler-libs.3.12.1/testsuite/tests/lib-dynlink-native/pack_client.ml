let () =
  print_endline Mypack.Packed1.mykey
