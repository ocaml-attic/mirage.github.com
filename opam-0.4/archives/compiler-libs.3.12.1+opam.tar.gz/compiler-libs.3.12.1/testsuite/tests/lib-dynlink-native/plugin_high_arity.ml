let f x x x x x x x x x x x x x = ()

let g x = f x x x x x x x x

let () =
  Api.reg_mod "HA"
