let () =
  ignore (Api.f 10)

