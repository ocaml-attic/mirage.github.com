4;;

(**
       0 CONSTINT 4
       2 ATOM0 
       3 SETGLOBAL T011-constint
       5 STOP 
**)
