let _ = () in Lib.x;;

(**
       0 CONSTINT 42
       2 PUSHACC0 
       3 MAKEBLOCK1 0
       5 POP 1
       7 SETGLOBAL Lib
       9 CONST0 
      10 PUSHGETGLOBALFIELD Lib, 0
      13 POP 1
      15 ATOM0 
      16 SETGLOBAL T051-pushgetglobalfield
      18 STOP 
**)
