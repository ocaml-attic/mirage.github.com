[1];;

(**
       0 GETGLOBAL <0>(1, 0)
       2 ATOM0 
       3 SETGLOBAL T050-getglobal
       5 STOP 
**)
