2;;

(**
       0 CONST2 
       1 ATOM0 
       2 SETGLOBAL T010-const2
       4 STOP 
**)
