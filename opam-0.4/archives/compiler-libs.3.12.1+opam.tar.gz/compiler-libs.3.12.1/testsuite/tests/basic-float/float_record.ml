type t = float;;

let make f = f;;

let from t = t;;

type s = {f : t};;
