static __inline__ void
__dt__8mystringFv (struct mystring *const this, int x)
{
  if (this != 0)
    {
    }
}
