

// Define an empty struct for now
struct empty  *ptr_empty;

int other() {
  return (sizeof(struct empty));
}
