struct s2 {
  int x;
} x1, x2; /* Constrain both s11 and s1 to be isomorphic  */

struct d2 {
  double x;
} y2, y1; /* Constrain both d11 and d1 to be isomorphic  */

