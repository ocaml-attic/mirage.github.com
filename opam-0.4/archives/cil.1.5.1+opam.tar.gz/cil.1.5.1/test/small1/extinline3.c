extern inline int f(void) { return 1; }

int g(void)
{
  return f();
}

