typedef struct foo *PFOO;

typedef struct foo {
  int x;
  PFOO y;
} *PTR;

PTR g1;
