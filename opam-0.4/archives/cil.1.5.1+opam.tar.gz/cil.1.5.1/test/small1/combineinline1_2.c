inline int foo(int x) {
  return x;
}


int getfoo2() {
  return (int)foo;
}
