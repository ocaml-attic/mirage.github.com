// Fron c-torture
/* Copyright (C) 2000  Free Software Foundation.

   by Alexandre Oliva  <oliva@lsd.ic.unicamp.br>  */

#pragma /* the token after #pragma is optional. */
