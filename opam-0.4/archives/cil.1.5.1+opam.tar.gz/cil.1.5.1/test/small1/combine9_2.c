typedef short INT; /* This was declared int before */

struct {
  INT i;
  int x;
} g;
