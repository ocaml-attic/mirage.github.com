typedef int ptrdiff_t;
typedef int FILE;
__inline static ptrdiff_t theFunc (FILE const *__18137_44___f) { }

