
extern int base_files[];
const char *const lang_dir_names[] = { "c",
((void *)0)};

int base_files[((sizeof (lang_dir_names) / sizeof ((lang_dir_names)[0])) - 1)]
= { sizeof(lang_dir_names[1]) }
;
