/* Try to reuse the enum types with the same name */
enum e1 {
  FIRST,
  SECOND,
} x1;

int main() {
  return x1;
}
