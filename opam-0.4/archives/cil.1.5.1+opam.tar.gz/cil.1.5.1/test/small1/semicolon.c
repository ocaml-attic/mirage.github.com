
struct foo {
  int g;;;
  char *d;
} x;


int main() {
  x.g = 1;
  return 0;
}
