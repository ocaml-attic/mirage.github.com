typedef char otherChar;
__inline static otherChar *
copyptrs (char *first, char *last,
	  otherChar * result, struct true_type const *_4)
{
}
