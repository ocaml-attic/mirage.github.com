

int bar()
{
  return 4;
}
