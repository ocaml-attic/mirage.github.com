// registers before assigning

#include <stdio.h>    // printf

void innerDoTreeStuff(int letGcFree)
{
  int i;

  /* Add and delete random numbers from the hash table */
  printf("inserting...\n");
}

int main()
{
  innerDoTreeStuff(0);
  return 0;
}
