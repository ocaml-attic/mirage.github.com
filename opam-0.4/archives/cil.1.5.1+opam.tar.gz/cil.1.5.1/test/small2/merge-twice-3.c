

int baz()
{
  return 7;
}
