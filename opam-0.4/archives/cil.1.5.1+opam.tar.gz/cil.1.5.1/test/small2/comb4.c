// comb4.c
// part 4/4 of a program expected to be combined

int global_com4 = 5;
int foo2_com2(int x);

int foo2_com4(int x)
{
  return foo2_com2(x) +4;
}

