type label = x:int -> int
  deriving (Eq)
