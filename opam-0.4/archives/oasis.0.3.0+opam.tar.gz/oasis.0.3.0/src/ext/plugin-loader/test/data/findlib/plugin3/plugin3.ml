let () =
  PluginloaderLib.registered_plugins :=
  "plugin3" :: !PluginloaderLib.registered_plugins
