
let registered_plugins : string list ref =
  ref []
