(* OASIS_START *)
(* DO NOT EDIT (digest: 0b0e578b6555b4d9716df8fd8342636b) *)
This is the README file for the ocaml-markdown distribution.

(C) 2009 Mauricio Fernandez

(C) 2010 Sylvain Le Gall

Markdown parser and printer

See the files INSTALL.txt for building and installation instructions. 


(* OASIS_STOP *)
