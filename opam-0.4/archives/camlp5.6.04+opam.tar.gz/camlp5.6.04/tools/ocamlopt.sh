#!/bin/sh -e

COMM=ocamlopt$OPT
echo $COMM $*
$COMM $*
