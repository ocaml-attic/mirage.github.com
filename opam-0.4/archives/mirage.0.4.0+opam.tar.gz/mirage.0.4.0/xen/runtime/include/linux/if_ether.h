#ifndef _LINUX_IF_ETHER_H
#define _LINUX_IF_ETHER_H

#include <net/if_ether.h>

#endif
