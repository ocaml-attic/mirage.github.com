#include <sys/types.h>

double __poly(double x, size_t n, const double* c);
