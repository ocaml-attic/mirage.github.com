?package(dypgen):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="dypgen" command="/usr/bin/dypgen"
