type menu_item =
  | Internal of Cow.Html.t
  | External

