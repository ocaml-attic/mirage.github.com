!function ($) {
  $(function(){
    window.prettyPrint && prettyPrint()

    // TODO: enable tooltips
    $('.tooltip-packages').tooltip({
      selector: "a[rel=tooltip]"
    })

  })
}(window.jQuery)
