
/* Constants */

/* maximum amount of resources allocated */
#define OCAML_IMAGEMAGICK_VERSION "0.33"

/*  8 * 1024 = 8192 ;;  16 * 1024 = 16384  */
#define MAX_AMOUNT 16384
#define TYPE_CHECKING 0
#define CHECK_VALS 0
#define DEBUG 0


#define CAML_FRAME 0

