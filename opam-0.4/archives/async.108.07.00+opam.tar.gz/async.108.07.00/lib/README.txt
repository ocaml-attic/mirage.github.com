To get an overview of Async, read the Dummy's guide to Async in the
docs repo.  If you want an overview of the code, start with std.ml and
follow the suggestions you'll find there.
