let is_prefix ?from:(pos=0) ~prefix:sub str =
  let str_len = String.length str in
  let sub_len = String.length sub in
  if pos + sub_len > str_len then false
  else 
    let rec iter i = 
      if str.[pos + i] <> sub.[i] then false
      else 
        let i' = i + 1 in
        if i' = sub_len then true
        else iter i'
    in
    iter 0

let index_string_from str pos sub =
  let sub_len = String.length sub in
  if sub_len = 0 then pos 
  else 
    let limit = String.length str - sub_len in
    let rec iter i = 
      if i > limit then raise Not_found
      else if is_prefix str ~from:i ~prefix:sub then i
      else iter (i+1)
    in
    iter pos

let is_postfix ~postfix:sub str =
  is_prefix ~from:(String.length str - String.length sub) ~prefix: sub str

let rec index_rec s lim i c =
  if i >= lim then None else
    if String.unsafe_get s i = c then Some i else index_rec s lim (i +
  1) c
;;
  
let index_from_to s from to_ c =
  let l = String.length s in
  if from < 0 || from > to_ || to_ >= l then 
    invalid_arg "Xstring.index_from_to" 
  else
    index_rec s (to_+1) from c
;;

let chop_newline s =
  let len = String.length s in
  if len > 1 && s.[len-1] = '\n' then
    if len > 2 && s.[len-2] = '\r' then String.sub s 0 (len-2)
    else String.sub s 0 (len-1)
  else s

let split_by_newline s =
  let length = String.length s in
  let rec aux st start_pos pos = 
    if pos = length then List.rev st else match s.[pos] with
    | '\r' | '\n' -> 
        let st = String.sub s start_pos (pos - start_pos) :: st in
        skip st (pos+1)
    | _ -> aux st start_pos (pos+1)
  and skip st pos = 
    if pos = length then List.rev st else match s.[pos] with
    | '\r' | '\n' -> skip st (pos+1)
    | _ -> aux st pos (pos+1)
  in
  aux [] 0 0

module Set = Xset.Make(struct type t = string let compare (x:string) y = compare x y end)
