open Int64

let ( + ) = add
let ( - ) = sub
let ( * ) = mul
let ( / ) = div
let (mod) =rem
