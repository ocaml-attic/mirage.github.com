(*

  Sub-shell call $`...` which calls `command'. The command variable must be bound manually.

*)

open Spotlib.Spot
let command = Spotlib.Spot.Unix.shell_command

let _ =
  $`ls .` & function
    | (`Out, `Read s) -> prerr_string ("OUT: " ^ s)
    | (`Err, `Read s) -> prerr_string ("ERR: " ^ s)
    | (`Out, `EOF) -> prerr_endline "OUT: EOF"
    | (`Err, `EOF) -> prerr_endline "ERR: EOF"
;;
    
let _ =
  <:qx<ls .>> & function
    | (`Out, `Read s) -> prerr_string ("OUT: " ^ s)
    | (`Err, `Read s) -> prerr_string ("ERR: " ^ s)
    | (`Out, `EOF) -> prerr_endline "OUT: EOF"
    | (`Err, `EOF) -> prerr_endline "ERR: EOF"
;;


    
