(*
  pre-compiled efficient sprintf $"xxx"
*)

let _ =
  assert ("hello" = $"hello");
  let w = "world" in
  assert ("hello world" = $"hello %s" w);
  assert ("hello world" = $"hello $w");
  assert ("hello worldworld" = $"hello ${w ^ w}");

  let x = 42 in
  assert ("answer = 42" = $"answer = %d" x);
  assert ("answer = 42" = $"answer = %${x}d");
  assert ("answer^2 = 1764" = $"answer^2 = %${x * x}d");
  (* assert ("123." = $"%${123.456}1.F"); (* it fails if ocaml bug in printf.ml is not fixed *) *)

  assert ("hello" = <:qq<hello>>);
  let w = "world" in
  assert ("hello world" = <:qq<hello %s>> w);
  assert ("hello world" = <:qq<hello $w>>);
  assert ("hello worldworld" = <:qq<hello ${w ^ w}>>);

  let x = 42 in
  assert ("answer = 42" = <:qq<answer = %d>> x);
  assert ("answer = 42" = <:qq<answer = %${x}d>>);
  assert ("answer^2 = 1764" = <:qq<answer^2 = %${x * x}d>>);
  (* assert ("123." = <:qq<%${123.456}1.F>>); (* it fails if ocaml bug in printf.ml is not fixed *) *)
;;

