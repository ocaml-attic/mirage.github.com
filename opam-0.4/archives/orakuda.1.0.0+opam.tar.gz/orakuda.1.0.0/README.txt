(* OASIS_START *)
(* DO NOT EDIT (digest: d74830faab2e3dbe7dc448b989bae66e) *)
This is the README file for the orakuda distribution.

ORakuda, Perlish string literals

See the files INSTALL.txt for building and installation instructions. 


(* OASIS_STOP *)
