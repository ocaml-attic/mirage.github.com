NAME

    pa_regexp: camlp4 extension for perl style pcre in ORakuda library

SYNOPSIS

    $/REX/[FLAGS]

        A regular expression of type Regexp.t. FLAGS are of 
	the following characters:

            i : caseless
	    m : multiline
	    s : dotall
	    x : extended
	    U : lazy
	    8 : UTF8 aware

        EXAMPLE

          $/foo\(\)/         (* no need to escape '\' *)

      $/REX/[FLAGS] [as x] -> e 
    | $/REX/[FLAGS] [as x] -> e
    | ...
    | _ -> e  

        A regular expression match function. A list of case bindings 
	$/REX/[FLAGS] [as x] -> e and an optional default case 
	at the end.

	A case biding [$/REX/[FLAGS] [as x] -> e] is a match using
	the regular expression $/REX/[FLAGS]. If the match succeeds,
	[e] is evaluated optionally with the variable binding of [x]
	to the result.

	If the match fails, the next case binding is tried. If all the
	cases fail, the expression [e] at the default case [| _ -> e]
	is evaluated. If the defualt case is omitted, the match raises
	[Not_found].

	EXAMPLE

           let (|!) x f = f x in      
	   string 
	     |! $/hello/i -> `Hello
	     |  $/number ([0-9]+)/ as x -> 
  		   `Number (int_of_string x#_0)   
             |  $/(?P<name>[a-z]+)=(?P<value>[0-9]+})/ as x ->
	           `Binding (x#name, int_of_string x#value)
             |  _ -> `None

        BUGS

           No easy type conversion yet.

    $s/REX/TEMPL/[FLAGS]

        A string replace function, which matches the target string
        with the regular experssion [REX] and replace the match(es) by
	the string [TEMPL]. In addition to the flags of
        [$/REX/[FLAGS]] above, the following flag can be used:
	
            g : replace globally

        EXAMPLE

            let s = $s/hello/bye/ig in ...

        BUGS

            Match result cannot be used.
	    Templates is restricted to string constants.


	
