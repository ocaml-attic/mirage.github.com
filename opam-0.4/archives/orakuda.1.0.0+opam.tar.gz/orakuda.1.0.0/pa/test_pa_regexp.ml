(* 
camlp4of xlexer.cmo lexrex.cmo pa_extlex.cmo pa_regexp.cmo test_pa_regexp.ml 
*)

let x = 1

let r = $/hello/;;
let r = $/hello/ as x -> "world"
let r = $/hello/ as x -> "world" | _ -> "default"

let r = $/hello/ -> "world"
let r = $/hello/ -> "world" | _ -> "default"
let r = $/hello/ -> "world" | $/bye/ as x -> "universe" | _ -> "default"
let r = $/hello/ -> "world" | $/bye/ -> "universe" | _ -> "default"

let rex v = [ $/hello/; v ];;

let y = 2

let _ = $/xxx/;;

$/xxx/;;

$/xxx/ as x -> "hello";;

let repl = $s/hello/world/
let repl = $s/hello/world/g

let s = $s/hello/world/ "helhe"
let s = Regexp.split $/hello/ "hehe"

let _ = "hello" ^$ $/world/ -> 1 | _ -> 0

