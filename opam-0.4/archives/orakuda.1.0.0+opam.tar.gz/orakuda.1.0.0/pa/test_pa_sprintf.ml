(* camlp4of xlexer.cmo pa_extlex.cmo xprintf.cmo pa_xprintf.cmo test_pa_xprintf.ml *)
let x = 1;;
let y = $"d";;
let z = $"%d";;
let w0 = $"%s%${x+1}d";;

