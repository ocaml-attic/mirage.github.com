(* OASIS_START *)
(* DO NOT EDIT (digest: 5f12229f42314f6d96f51c22fdc49971) *)
This is the README file for the treeprint distribution.

Small tree structure printer with operator associations and precedences.

See the files INSTALL.txt for building and installation instructions. 


(* OASIS_STOP *)
