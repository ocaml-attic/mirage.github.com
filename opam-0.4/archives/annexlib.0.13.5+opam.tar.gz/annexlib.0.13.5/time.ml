(* time utility routines for ocaml
   Copyright (C) 2002,2003 Shawn Wagner <raevnos@pennmush.org>

   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.
	 
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
	 
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*)

(* Time utility functions to fill in gaps in the Unix library *)

type timeval = {
  tv_sec: int32;
  tv_usec: int32
}

external time : unit -> int32 = "stew_time_int32"
external localtime: int32 -> Unix.tm = "stew_localtime"
external gmtime: int32 -> Unix.tm = "stew_gmtime"
external mktime: Unix.tm -> int32 * Unix.tm = "stew_mktime"
external format_tm: string -> Unix.tm -> string = "stew_strftime_tm"
external _parse_tm: string -> string -> Unix.tm = "stew_strptime_tm"
external ctime: int32 -> string = "stew_ctime"
external asctime: Unix.tm -> string = "stew_asctime"
external difftime: int32 -> int32 -> float = "stew_difftime"
external gettimeofday: unit -> timeval = "stew_gettimeofday"


let format_time fmt tm = format_tm fmt (localtime tm)

let parse_tm fmt s =
  try _parse_tm s fmt with
      Failure _ -> failwith ("parsing '" ^ s ^ "' with format '" ^ 
                             fmt ^ "' failed.")
        
let parse_time fmt s = fst (mktime (parse_tm fmt s))

let time_string tyme =
  let s = ctime tyme in
    StrExtras.chomp s

let tm_string tm =
  let s = asctime tm in
    StrExtras.chomp s
