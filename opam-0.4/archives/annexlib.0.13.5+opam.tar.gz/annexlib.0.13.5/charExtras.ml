(* character utility routines for ocaml
   Copyright (C) 2002 Shawn Wagner <raevnos@pennmush.org>

   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.
	 
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
	 
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*)

(* Set and query the current CTYPE locale *)

let set_chartype name =
  Locale.set ~name `LC_CTYPE
let get_chartype () = Option.default (Locale.set `LC_CTYPE) ""

(* Test characters *)
external is_alpha : char -> bool = "stew_is_alpha"
external is_space : char -> bool = "stew_is_space"
external is_number : char -> bool = "stew_is_number"
external is_lower : char -> bool = "stew_is_lower"
external is_upper : char -> bool = "stew_is_upper" 
let is_alphanumeric c = is_alpha c or is_number c
external is_punctation : char -> bool = "stew_is_punct"
external is_printable : char -> bool = "stew_is_print"
external is_graphical : char -> bool = "stew_is_graph"
external is_hexadecimal : char -> bool = "stew_is_xdigit" 

(* Convert to lowercase/uppercae according to current locale *)
external to_lower : char -> char = "stew_to_lower"
external to_upper : char -> char = "stew_to_upper" 
