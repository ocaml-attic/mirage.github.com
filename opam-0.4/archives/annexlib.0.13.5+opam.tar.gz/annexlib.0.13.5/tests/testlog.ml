#use "findlib";;
#require "stew";;

Syslog.openlog "tester" [Syslog.LOG_PERROR;Syslog.LOG_PID] Syslog.LOG_USER;;
Syslog.syslog Syslog.LOG_INFO "This is a test message.";;
Syslog.syslog ~fac:Syslog.LOG_DAEMON Syslog.LOG_WARNING "A warning message";;
Syslog.closelog ();;
Printf.printf "My pid: %d\n" (Unix.getpid());;
