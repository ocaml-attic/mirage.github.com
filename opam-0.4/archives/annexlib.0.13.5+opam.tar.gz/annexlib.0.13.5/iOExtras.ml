(* I/O utility routines for ocaml
   Copyright (C) 2003 Shawn Wagner <raevnos@pennmush.org>

   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.
	 
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
	 
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*)

(* print_endline on a generic channel, or stdout if one isn't given  *)
let output_endline ostream str =
  output_string ostream str;
  output_char ostream '\n'

(* Open a file for output and auto-close it when the program exits. *)
let open_out filename =
	let ostream = open_out filename in
	let f = function () -> close_out ostream in
	  at_exit f;
	  ostream

let cont_re = Pcre.regexp "(?<!\\\\)\\\\$"

let input_continued ?(squish=false) istream =  
  let b = Buffer.create 512 
  and cont = ref true 
  and first = ref true in
    while !cont do
      let s = 
	let s' = input_line istream in
	  if not !first && squish then 
	    Pcre.qreplace_first ~pat:"^\\s+" ~templ:"" s'
	      (*
		begin let x = ref 0 in
		while CharExtras.is_space s'.[!x] do
		incr x
		done;
		StrExtras.cut_first_n s' !x
		end
	      *)
	  else
	    s' in
	first := false;
	if Pcre.pmatch ~rex:cont_re s then 
	  Buffer.add_substring b s 0 (String.length s - 1)
	else begin
	  Buffer.add_string b s;
	  cont := false
	end
	  (*	  if StrExtras.right s 2 = "\\/" then begin 
		  Buffer.add_string b s;
		  cont := false
		  end else if StrExtras.right s 1 = "/" then 
		  Buffer.add_substring b s 0 (String.length s - 1)
		  else begin
		  Buffer.add_string b s;
		  cont := false
		  end
	  *)
    done;
    Buffer.contents b

open Unix

let snarf_file filename =
  let fd = openfile filename [O_RDONLY] 0 in
  let size = (fstat fd).st_size in
  let s = String.create size
  and len = ref size 
  and ofs = ref 0 in
    while !ofs < size do
      let bytes = read fd s !ofs !len in
	len := !len - bytes;
	ofs := !ofs + bytes;
    done;
    close fd;
    s
